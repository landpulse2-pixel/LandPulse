'use client';

import { useEffect } from 'react';
import { useGameStore } from '@/store/gameStore';
import { Header } from '@/components/landpulse/Header';
import { WorldMap } from '@/components/landpulse/WorldMap';
import { Dashboard } from '@/components/landpulse/Dashboard';
import { EventsPanel } from '@/components/landpulse/EventsPanel';
import { LandingPage } from '@/components/landpulse/LandingPage';

export default function Home() {
  const { isConnected, activeTab, walletAddress, setUser, setConnected, setParcels, setLoading } = useGameStore();

  // Check for existing session on mount
  useEffect(() => {
    const checkSession = async () => {
      const stored = localStorage.getItem('landpulse-storage');
      if (stored) {
        try {
          const parsed = JSON.parse(stored);
          if (parsed.state?.walletAddress) {
            // Fetch user data
            setLoading(true);
            const response = await fetch(`/api/user?wallet=${parsed.state.walletAddress}`);
            const data = await response.json();
            
            if (data.user) {
              setUser(data.user);
              setConnected(true, parsed.state.walletAddress);
              
              // Fetch parcels
              const parcelsResponse = await fetch(`/api/parcels?wallet=${parsed.state.walletAddress}`);
              const parcelsData = await parcelsResponse.json();
              setParcels(parcelsData.parcels || []);
            }
          }
        } catch (error) {
          console.error('Error restoring session:', error);
        } finally {
          setLoading(false);
        }
      }
    };

    checkSession();
  }, [setUser, setConnected, setParcels, setLoading]);

  // Show landing page if not connected
  if (!isConnected) {
    return <LandingPage />;
  }

  // Main app when connected
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-6">
        {activeTab === 'map' && <WorldMap />}
        {activeTab === 'dashboard' && <Dashboard />}
        {activeTab === 'events' && <EventsPanel />}
      </main>

      <footer className="py-4 px-4 border-t border-purple-500/20">
        <div className="container mx-auto flex items-center justify-between text-xs text-muted-foreground">
          <span>LandPulse Beta • Phase 1</span>
          <span>Built on Solana</span>
        </div>
      </footer>
    </div>
  );
}
