import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

// POST /api/buildings/collect - Collect accumulated points from all parcels
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { wallet } = body;

    if (!wallet) {
      return NextResponse.json({ error: 'Wallet address required' }, { status: 400 });
    }

    // Get user with parcels
    const user = await prisma.user.findUnique({
      where: { walletAddress: wallet },
      include: {
        parcels: true,
      },
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Calculate total points to collect
    const now = Date.now();
    let totalPoints = 0;

    // Calculate points from all parcels
    for (const parcel of user.parcels) {
      // Calculate points since last collection (or purchase)
      const purchaseTime = parcel.purchasedAt.getTime();
      const elapsedTime = (now - purchaseTime) / 1000; // in seconds
      const points = parcel.pointsPerSecond * elapsedTime;
      totalPoints += points;
    }

    // Apply boost if active
    let multiplier = 1;
    if (user.boostEndTime && new Date(user.boostEndTime) > new Date()) {
      multiplier = 2;
      totalPoints *= multiplier;
    }

    if (totalPoints <= 0) {
      return NextResponse.json({ 
        collected: 0, 
        message: 'Aucun point à collecter' 
      });
    }

    // Update user points and reset collection time
    const result = await prisma.$transaction(async (tx) => {
      // Update user points
      const updatedUser = await tx.user.update({
        where: { id: user.id },
        data: {
          points: { increment: totalPoints },
          totalPointsEarned: { increment: totalPoints },
        },
      });

      // Reset parcel purchase times (collection time)
      await tx.parcel.updateMany({
        where: { ownerId: user.id },
        data: { purchasedAt: new Date() },
      });

      // Create transaction record
      await tx.transaction.create({
        data: {
          userId: user.id,
          type: 'collect_points',
          amount: totalPoints,
          metadata: JSON.stringify({
            multiplier,
            parcelCount: user.parcels.length,
          }),
        },
      });

      return updatedUser;
    });

    return NextResponse.json({
      success: true,
      collected: Math.floor(totalPoints),
      multiplier,
      newTotal: result.points,
    });
  } catch (error) {
    console.error('Error collecting points:', error);
    return NextResponse.json({ error: 'Failed to collect points' }, { status: 500 });
  }
}
