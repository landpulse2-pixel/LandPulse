import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { GAME_CONFIG, getRandomRarity, calculateParcelPrice } from '@/lib/game-config';

// POST /api/parcels/buy - Buy a new parcel
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { wallet, lat, lng, price } = body;

    if (!wallet || lat === undefined || lng === undefined) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Get or create user
    let user = await prisma.user.findUnique({
      where: { walletAddress: wallet }
    });

    if (!user) {
      user = await prisma.user.create({
        data: {
          walletAddress: wallet,
          pulseBucks: GAME_CONFIG.INITIAL_PULSE_BUCKS,
          points: GAME_CONFIG.INITIAL_POINTS,
        }
      });
    }

    // Calculate actual price
    const actualPrice = calculateParcelPrice(lat, lng);

    // Check if user has enough PulseBucks
    if (user.pulseBucks < actualPrice) {
      return NextResponse.json({ 
        error: `PulseBucks insuffisants. Vous avez ${user.pulseBucks} PB, besoin de ${actualPrice} PB` 
      }, { status: 400 });
    }

    // Check if parcel already exists at this location
    // Round coordinates to parcel grid
    const parcelSize = GAME_CONFIG.MAP.parcelSizeDegrees;
    const gridLat = Math.round(lat / parcelSize) * parcelSize;
    const gridLng = Math.round(lng / parcelSize) * parcelSize;

    const existingParcel = await prisma.parcel.findFirst({
      where: {
        lat: { gte: gridLat - parcelSize/2, lte: gridLat + parcelSize/2 },
        lng: { gte: gridLng - parcelSize/2, lte: gridLng + parcelSize/2 },
      }
    });

    if (existingParcel) {
      return NextResponse.json({ error: 'Cette parcelle est déjà possédée' }, { status: 400 });
    }

    // Determine rarity (random lottery)
    const rarity = getRandomRarity();
    const rarityConfig = GAME_CONFIG.RARITY_LEVELS[rarity];

    // Calculate points per second based on rarity
    const basePointsPerSecond = 0.0001; // Base: ~8.64 points per day
    const pointsPerSecond = basePointsPerSecond * rarityConfig.incomeMultiplier;

    // Create parcel and update user in a transaction
    const result = await prisma.$transaction(async (tx) => {
      // Create parcel
      const parcel = await tx.parcel.create({
        data: {
          lat: gridLat,
          lng: gridLng,
          level: rarity,
          pointsPerSecond,
          ownerId: user!.id,
          improvementLevel: 0,
        }
      });

      // Deduct PulseBucks
      await tx.user.update({
        where: { id: user!.id },
        data: {
          pulseBucks: { decrement: actualPrice },
          totalSpent: { increment: actualPrice },
        }
      });

      // Create transaction record
      await tx.transaction.create({
        data: {
          userId: user!.id,
          type: 'purchase_parcel',
          amount: actualPrice,
          metadata: JSON.stringify({
            parcelId: parcel.id,
            lat: gridLat,
            lng: gridLng,
            rarity,
          }),
        }
      });

      return parcel;
    });

    return NextResponse.json({
      success: true,
      parcel: {
        id: result.id,
        lat: result.lat,
        lng: result.lng,
        level: result.level,
        pointsPerSecond: result.pointsPerSecond,
        price: actualPrice,
      }
    });
  } catch (error) {
    console.error('Error buying parcel:', error);
    return NextResponse.json({ error: 'Failed to buy parcel' }, { status: 500 });
  }
}
