import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { GAME_CONFIG, getRandomRarity, calculateParcelPrice } from '@/lib/game-config';

// GET /api/parcels - Get user's parcels or parcels in an area
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const wallet = searchParams.get('wallet');
    const lat = searchParams.get('lat');
    const lng = searchParams.get('lng');
    const radius = searchParams.get('radius'); // in km

    if (wallet) {
      // Get user's parcels
      const user = await prisma.user.findUnique({
        where: { walletAddress: wallet },
        include: {
          parcels: {
            include: {
              owner: {
                select: { walletAddress: true }
              }
            }
          }
        }
      });

      if (!user) {
        return NextResponse.json({ parcels: [] });
      }

      const parcels = user.parcels.map(parcel => ({
        id: parcel.id,
        lat: parcel.lat,
        lng: parcel.lng,
        level: parcel.level,
        price: calculateParcelPrice(parcel.lat, parcel.lng),
        name: `${parcel.lat.toFixed(4)}°N ${parcel.lng.toFixed(4)}°E`,
        pointsPerSecond: parcel.pointsPerSecond,
        improvementLevel: parcel.improvementLevel,
        isOwned: true,
        isOwnedByUser: true,
        ownerWallet: wallet,
      }));

      return NextResponse.json({ parcels });
    }

    // Get parcels in area (for map display)
    if (lat && lng && radius) {
      const latNum = parseFloat(lat);
      const lngNum = parseFloat(lng);
      const radiusNum = parseFloat(radius);
      
      // Convert km to degrees (approximate)
      const latDiff = radiusNum / 111; // 1 degree lat ≈ 111 km
      const lngDiff = radiusNum / (111 * Math.cos(latNum * Math.PI / 180));

      const parcels = await prisma.parcel.findMany({
        where: {
          lat: {
            gte: latNum - latDiff,
            lte: latNum + latDiff,
          },
          lng: {
            gte: lngNum - lngDiff,
            lte: lngNum + lngDiff,
          },
        },
        include: {
          owner: {
            select: { walletAddress: true }
          }
        }
      });

      const formattedParcels = parcels.map(parcel => ({
        id: parcel.id,
        lat: parcel.lat,
        lng: parcel.lng,
        level: parcel.level,
        price: calculateParcelPrice(parcel.lat, parcel.lng),
        name: `${parcel.lat.toFixed(4)}°N ${parcel.lng.toFixed(4)}°E`,
        pointsPerSecond: parcel.pointsPerSecond,
        improvementLevel: parcel.improvementLevel,
        isOwned: !!parcel.ownerId,
        isOwnedByUser: false, // Will be set by client
        ownerWallet: parcel.owner?.walletAddress,
      }));

      return NextResponse.json({ parcels: formattedParcels });
    }

    return NextResponse.json({ parcels: [] });
  } catch (error) {
    console.error('Error fetching parcels:', error);
    return NextResponse.json({ error: 'Failed to fetch parcels' }, { status: 500 });
  }
}
