import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { GAME_CONFIG } from '@/lib/game-config';

// GET /api/user - Get user by wallet address
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const wallet = searchParams.get('wallet');

    if (!wallet) {
      return NextResponse.json({ error: 'Wallet address required' }, { status: 400 });
    }

    const user = await prisma.user.findUnique({
      where: { walletAddress: wallet },
    });

    if (!user) {
      return NextResponse.json({ user: null });
    }

    return NextResponse.json({
      user: {
        id: user.id,
        walletAddress: user.walletAddress,
        pulseBucks: user.pulseBucks,
        points: user.points,
        totalPointsEarned: user.totalPointsEarned,
        lastDailyBonus: user.lastDailyBonus?.toISOString(),
        totalEarned: user.totalEarned,
        totalSpent: user.totalSpent,
        boostEndTime: user.boostEndTime?.toISOString(),
      },
    });
  } catch (error) {
    console.error('Error fetching user:', error);
    return NextResponse.json({ error: 'Failed to fetch user' }, { status: 500 });
  }
}

// POST /api/user - Create or get user
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { walletAddress } = body;

    if (!walletAddress) {
      return NextResponse.json({ error: 'Wallet address required' }, { status: 400 });
    }

    // Check if user exists
    let user = await prisma.user.findUnique({
      where: { walletAddress },
    });

    if (!user) {
      // Create new user with initial balance
      user = await prisma.user.create({
        data: {
          walletAddress,
          pulseBucks: GAME_CONFIG.INITIAL_PULSE_BUCKS,
          points: GAME_CONFIG.INITIAL_POINTS,
        },
      });
    }

    return NextResponse.json({
      user: {
        id: user.id,
        walletAddress: user.walletAddress,
        pulseBucks: user.pulseBucks,
        points: user.points,
        totalPointsEarned: user.totalPointsEarned,
        lastDailyBonus: user.lastDailyBonus?.toISOString(),
        totalEarned: user.totalEarned,
        totalSpent: user.totalSpent,
        boostEndTime: user.boostEndTime?.toISOString(),
      },
    });
  } catch (error) {
    console.error('Error creating user:', error);
    return NextResponse.json({ error: 'Failed to create user' }, { status: 500 });
  }
}
