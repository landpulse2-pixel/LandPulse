// LandPulse Game Configuration - Updated with new economy model

export const GAME_CONFIG = {
  // Initial PulseBucks for new users
  INITIAL_PULSE_BUCKS: 100,
  
  // Initial Points for new users
  INITIAL_POINTS: 0,
  
  // Daily bonus in PulseBucks
  DAILY_BONUS: 10,
  DAILY_BONUS_COOLDOWN: 24 * 60 * 60 * 1000, // 24 hours in ms
  
  // Points conversion rate: 1,000,000 Points = $1
  POINTS_TO_DOLLAR: 1000000,
  
  // Parcel settings - 100m² virtual parcels
  PARCEL_SIZE_METERS: 100,
  PARCEL_BASE_PRICE_PB: 50, // Base price in PulseBucks
  
  // Rarity levels with probability and income multiplier
  RARITY_LEVELS: {
    common: {
      name: 'Commun',
      emoji: '🟢',
      probability: 0.50, // 50%
      incomeMultiplier: 1,
      color: '#10b981',
    },
    rare: {
      name: 'Rare',
      emoji: '🔵',
      probability: 0.30, // 30%
      incomeMultiplier: 1.5,
      color: '#3b82f6',
    },
    epic: {
      name: 'Épique',
      emoji: '🟣',
      probability: 0.15, // 15%
      incomeMultiplier: 2.5,
      color: '#8b5cf6',
    },
    legendary: {
      name: 'Légendaire',
      emoji: '🟠',
      probability: 0.05, // 5%
      incomeMultiplier: 5,
      color: '#f59e0b',
    },
  },
  
  // Building types - prices in PulseBucks, income in Points
  BUILDINGS: {
    house: {
      name: 'Maison',
      emoji: '🏠',
      price: 100, // PulseBucks
      pointsPerDay: 10000, // Points per day
      capacity: 1, // Can boost 1 parcel
      boostPercent: 10,
      description: 'Une maison confortable qui génère des revenus passifs. ROI: ~100 jours',
      roiDays: 100,
    },
    office: {
      name: 'Bureau',
      emoji: '🏢',
      price: 500,
      pointsPerDay: 60000,
      capacity: 2,
      boostPercent: 20,
      description: 'Un bureau moderne pour des revenus accrus. ROI: ~83 jours',
      roiDays: 83,
    },
    factory: {
      name: 'Usine',
      emoji: '🏭',
      price: 2000,
      pointsPerDay: 300000,
      capacity: 3,
      boostPercent: 35,
      description: 'Une usine industrielle pour des revenus élevés. ROI: ~66 jours',
      roiDays: 66,
    },
    castle: {
      name: 'Château',
      emoji: '🏰',
      price: 10000,
      pointsPerDay: 1330000,
      capacity: 4,
      boostPercent: 50,
      description: 'Un château royal avec les meilleurs revenus. ROI: ~75 jours',
      roiDays: 75,
    },
  },
  
  // PulseBucks purchase packages
  PB_PACKAGES: [
    { pb: 100, price: 0.99, bonus: 0 },
    { pb: 500, price: 4.99, bonus: 25 },
    { pb: 1000, price: 9.99, bonus: 100 },
    { pb: 5000, price: 49.99, bonus: 1000 },
    { pb: 10000, price: 99.99, bonus: 2500 },
  ],
  
  // Ad boost settings
  AD_BOOST: {
    duration: 60, // minutes
    multiplier: 2, // x2 income
    adDuration: 30, // seconds
  },
  
  // Map settings
  MAP: {
    defaultCenter: [0, 20] as [number, number], // lng, lat
    defaultZoom: 2,
    minZoom: 1,
    maxZoom: 18,
    parcelSizeDegrees: 0.001, // ~100m at equator
  },
  
  // Event types
  EVENT_TYPES: {
    quiz: {
      name: 'Quiz Challenge',
      description: 'Answer questions to earn rewards',
      baseReward: 20,
    },
    prediction: {
      name: 'SOL Prediction',
      description: 'Predict SOL price movements',
      baseReward: 30,
    },
    challenge: {
      name: 'Daily Challenge',
      description: 'Complete special tasks',
      baseReward: 25,
    },
  },
} as const;

// Helper function to get random rarity
export function getRandomRarity(): keyof typeof GAME_CONFIG.RARITY_LEVELS {
  const rand = Math.random();
  let cumulative = 0;
  
  for (const [rarity, config] of Object.entries(GAME_CONFIG.RARITY_LEVELS)) {
    cumulative += config.probability;
    if (rand <= cumulative) {
      return rarity as keyof typeof GAME_CONFIG.RARITY_LEVELS;
    }
  }
  
  return 'common';
}

// Helper function to calculate parcel price based on location
export function calculateParcelPrice(lat: number, lng: number): number {
  // Higher prices near city centers and popular locations
  // For now, use a simple distance-based calculation
  const basePrice = GAME_CONFIG.PARCEL_BASE_PRICE_PB;
  
  // Famous locations have higher prices
  const famousLocations = [
    { lat: 40.7128, lng: -74.0060, name: 'New York', multiplier: 3 },
    { lat: 51.5074, lng: -0.1278, name: 'London', multiplier: 2.5 },
    { lat: 35.6762, lng: 139.6503, name: 'Tokyo', multiplier: 2.5 },
    { lat: 48.8566, lng: 2.3522, name: 'Paris', multiplier: 2.5 },
    { lat: -33.8688, lng: 151.2093, name: 'Sydney', multiplier: 2 },
    { lat: 1.3521, lng: 103.8198, name: 'Singapore', multiplier: 2 },
    { lat: 25.2048, lng: 55.2708, name: 'Dubai', multiplier: 2 },
    { lat: -22.9068, lng: -43.1729, name: 'Rio', multiplier: 1.5 },
  ];
  
  let maxMultiplier = 1;
  
  for (const loc of famousLocations) {
    const distance = Math.sqrt(
      Math.pow(lat - loc.lat, 2) + Math.pow(lng - loc.lng, 2)
    );
    if (distance < 1) { // Within ~100km
      const proximityMultiplier = 1 + (loc.multiplier - 1) * (1 - distance);
      maxMultiplier = Math.max(maxMultiplier, proximityMultiplier);
    }
  }
  
  return Math.round(basePrice * maxMultiplier);
}

// Generate parcel name from coordinates
export function generateParcelName(lat: number, lng: number): string {
  const latDir = lat >= 0 ? 'N' : 'S';
  const lngDir = lng >= 0 ? 'E' : 'W';
  const latStr = Math.abs(lat).toFixed(4);
  const lngStr = Math.abs(lng).toFixed(4);
  return `${latStr}°${latDir} ${lngStr}°${lngDir}`;
}

// Format large numbers with suffixes
export function formatNumber(num: number): string {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M';
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K';
  }
  return num.toString();
}

// Format points to dollar equivalent
export function pointsToDollarString(points: number): string {
  const dollars = points / GAME_CONFIG.POINTS_TO_DOLLAR;
  return '$' + dollars.toFixed(6);
}
