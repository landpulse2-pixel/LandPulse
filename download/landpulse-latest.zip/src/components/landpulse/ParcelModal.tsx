'use client';

import { useEffect, useState } from 'react';
import { useGameStore, Parcel, Building } from '@/store/gameStore';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  GAME_CONFIG,
  formatNumber,
  pointsToDollarString,
} from '@/lib/game-config';
import {
  MapPin,
  Coins,
  Building2,
  Sparkles,
  Loader2,
  CheckCircle,
  Lock,
  Crown,
  Factory,
  Building as BuildingIcon,
  Home,
} from 'lucide-react';

interface ParcelModalProps {
  onRefresh: () => void;
}

export function ParcelModal({ onRefresh }: ParcelModalProps) {
  const { selectedParcel, setSelectedParcel, user, updatePulseBucks, addParcel } = useGameStore();
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [purchaseSuccess, setPurchaseSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [parcelBuildings, setParcelBuildings] = useState<Building[]>([]);
  const [selectedBuilding, setSelectedBuilding] = useState<string | null>(null);
  const [isBuilding, setIsBuilding] = useState(false);

  const isOpen = selectedParcel !== null;

  useEffect(() => {
    if (selectedParcel?.buildings) {
      setParcelBuildings(selectedParcel.buildings);
    } else {
      setParcelBuildings([]);
    }
  }, [selectedParcel]);

  const handleClose = () => {
    setSelectedParcel(null);
    setPurchaseSuccess(false);
    setError(null);
    setSelectedBuilding(null);
  };

  const handlePurchase = async () => {
    if (!selectedParcel || !user) return;

    // Check if user has enough PulseBucks
    if (user.pulseBucks < selectedParcel.price) {
      setError('PulseBucks insuffisants!');
      return;
    }

    setIsPurchasing(true);
    setError(null);

    try {
      const response = await fetch('/api/parcels/buy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lat: selectedParcel.lat,
          lng: selectedParcel.lng,
          price: selectedParcel.price,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        setPurchaseSuccess(true);
        updatePulseBucks(-selectedParcel.price);
        
        // Update parcel with ownership info
        const updatedParcel: Parcel = {
          ...selectedParcel,
          id: data.parcel.id,
          level: data.parcel.level,
          pointsPerSecond: data.parcel.pointsPerSecond,
          isOwned: true,
          isOwnedByUser: true,
          ownerId: user.id,
        };
        
        addParcel(updatedParcel);
        onRefresh();
      } else {
        setError(data.error || 'Erreur lors de l\'achat');
      }
    } catch (err) {
      setError('Erreur de connexion');
      console.error(err);
    } finally {
      setIsPurchasing(false);
    }
  };

  const handleBuild = async () => {
    if (!selectedBuilding || !selectedParcel || !user) return;

    const buildingConfig = GAME_CONFIG.BUILDINGS[selectedBuilding as keyof typeof GAME_CONFIG.BUILDINGS];
    
    if (user.pulseBucks < buildingConfig.price) {
      setError('PulseBucks insuffisants!');
      return;
    }

    setIsBuilding(true);
    setError(null);

    try {
      const response = await fetch('/api/buildings/build', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          parcelId: selectedParcel.id,
          buildingType: selectedBuilding,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        updatePulseBucks(-buildingConfig.price);
        setParcelBuildings([...parcelBuildings, data.building]);
        onRefresh();
      } else {
        setError(data.error || 'Erreur lors de la construction');
      }
    } catch (err) {
      setError('Erreur de connexion');
      console.error(err);
    } finally {
      setIsBuilding(false);
    }
  };

  const getBuildingIcon = (type: string) => {
    switch (type) {
      case 'house': return <Home className="h-5 w-5" />;
      case 'office': return <BuildingIcon className="h-5 w-5" />;
      case 'factory': return <Factory className="h-5 w-5" />;
      case 'castle': return <Crown className="h-5 w-5" />;
      default: return <Building2 className="h-5 w-5" />;
    }
  };

  if (!selectedParcel) return null;

  const rarityConfig = GAME_CONFIG.RARITY_LEVELS[selectedParcel.level];
  const canPurchase = !selectedParcel.isOwned && user && user.pulseBucks >= selectedParcel.price;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="glass-card border-purple-500/30 max-w-lg">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-lg flex items-center justify-center text-2xl"
              style={{ backgroundColor: `${rarityConfig.color}20` }}
            >
              {rarityConfig.emoji}
            </div>
            <div>
              <DialogTitle className="text-xl">
                {selectedParcel.name}
              </DialogTitle>
              <DialogDescription className="flex items-center gap-2 mt-1">
                <MapPin className="h-3 w-3" />
                {selectedParcel.lat.toFixed(4)}°, {selectedParcel.lng.toFixed(4)}°
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        {purchaseSuccess ? (
          <div className="py-8 text-center">
            <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Parcelle achetée!</h3>
            <p className="text-muted-foreground mb-4">
              Rareté: {rarityConfig.emoji} {rarityConfig.name}
            </p>
            <Button onClick={handleClose} className="gradient-bg">
              Fermer
            </Button>
          </div>
        ) : (
          <Tabs defaultValue="info" className="mt-4">
            <TabsList className="grid w-full grid-cols-2 glass-card">
              <TabsTrigger value="info">Informations</TabsTrigger>
              {selectedParcel.isOwnedByUser && (
                <TabsTrigger value="build">Construire</TabsTrigger>
              )}
            </TabsList>

            <TabsContent value="info" className="space-y-4 mt-4">
              {/* Rarity & Price */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Badge 
                    variant="outline" 
                    style={{ borderColor: rarityConfig.color, color: rarityConfig.color }}
                  >
                    {rarityConfig.name}
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    x{rarityConfig.incomeMultiplier} revenus
                  </span>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-yellow-400">
                    {selectedParcel.price} PB
                  </div>
                  {selectedParcel.pointsPerSecond > 0 && (
                    <div className="text-xs text-green-400">
                      +{(selectedParcel.pointsPerSecond * 86400).toFixed(0)} pts/jour
                    </div>
                  )}
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-3">
                <div className="glass-card rounded-lg p-3">
                  <div className="text-xs text-muted-foreground">Points/sec</div>
                  <div className="text-lg font-semibold text-green-400">
                    {selectedParcel.pointsPerSecond.toFixed(4)}
                  </div>
                </div>
                <div className="glass-card rounded-lg p-3">
                  <div className="text-xs text-muted-foreground">Amélioration</div>
                  <div className="text-lg font-semibold">
                    Niveau {selectedParcel.improvementLevel}/10
                  </div>
                </div>
              </div>

              {/* Buildings */}
              {parcelBuildings.length > 0 && (
                <div>
                  <div className="text-sm font-medium mb-2">Bâtiments ({parcelBuildings.length})</div>
                  <div className="flex gap-2">
                    {parcelBuildings.map((building) => (
                      <div 
                        key={building.id}
                        className="glass-card rounded-lg p-2 flex items-center gap-2"
                      >
                        {getBuildingIcon(building.type)}
                        <span className="text-sm">{building.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Owner Info */}
              {selectedParcel.isOwned && !selectedParcel.isOwnedByUser && (
                <div className="flex items-center gap-2 text-muted-foreground bg-red-500/10 rounded-lg p-3">
                  <Lock className="h-4 w-4" />
                  <span className="text-sm">
                    Propriétaire: {selectedParcel.ownerWallet?.slice(0, 8)}...{selectedParcel.ownerWallet?.slice(-4)}
                  </span>
                </div>
              )}

              {error && (
                <div className="text-sm text-red-400 bg-red-500/10 rounded-lg p-3">
                  {error}
                </div>
              )}

              {/* Purchase Button */}
              {!selectedParcel.isOwned && (
                <Button
                  onClick={handlePurchase}
                  disabled={!canPurchase || isPurchasing}
                  className="w-full gradient-bg"
                  size="lg"
                >
                  {isPurchasing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Achat en cours...
                    </>
                  ) : !user ? (
                    'Connectez votre wallet'
                  ) : user.pulseBucks < selectedParcel.price ? (
                    <>
                      <Coins className="mr-2 h-4 w-4" />
                      PulseBucks insuffisants ({user.pulseBucks.toFixed(0)}/{selectedParcel.price})
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2 h-4 w-4" />
                      Acheter cette parcelle
                    </>
                  )}
                </Button>
              )}
            </TabsContent>

            {selectedParcel.isOwnedByUser && (
              <TabsContent value="build" className="space-y-4 mt-4">
                <div className="text-sm text-muted-foreground mb-2">
                  Construisez des bâtiments pour augmenter vos revenus
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {Object.entries(GAME_CONFIG.BUILDINGS).map(([key, config]) => (
                    <div
                      key={key}
                      onClick={() => setSelectedBuilding(key)}
                      className={`
                        glass-card rounded-lg p-3 cursor-pointer transition-all
                        ${selectedBuilding === key ? 'border-purple-500 bg-purple-500/10' : 'hover:border-purple-500/50'}
                      `}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-2xl">{config.emoji}</span>
                        <span className="font-medium">{config.name}</span>
                      </div>
                      <div className="text-xs text-muted-foreground mb-2">
                        {config.description}
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-yellow-400">{config.price} PB</span>
                        <span className="text-green-400">
                          +{formatNumber(config.pointsPerDay)} pts/j
                        </span>
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        ROI: ~{config.roiDays} jours
                      </div>
                    </div>
                  ))}
                </div>

                {error && (
                  <div className="text-sm text-red-400 bg-red-500/10 rounded-lg p-3">
                    {error}
                  </div>
                )}

                {selectedBuilding && (
                  <Button
                    onClick={handleBuild}
                    disabled={!user || user.pulseBucks < GAME_CONFIG.BUILDINGS[selectedBuilding as keyof typeof GAME_CONFIG.BUILDINGS].price || isBuilding}
                    className="w-full gradient-bg"
                  >
                    {isBuilding ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Construction...
                      </>
                    ) : (
                      <>
                        <Building2 className="mr-2 h-4 w-4" />
                        Construire {GAME_CONFIG.BUILDINGS[selectedBuilding as keyof typeof GAME_CONFIG.BUILDINGS].name}
                      </>
                    )}
                  </Button>
                )}
              </TabsContent>
            )}
          </Tabs>
        )}
      </DialogContent>
    </Dialog>
  );
}
