'use client';

import { useGameStore } from '@/store/gameStore';
import { Coins, TrendingUp } from 'lucide-react';
import { formatNumber, pointsToDollarString } from '@/lib/game-config';

export function PulseBucksDisplay() {
  const { user } = useGameStore();

  if (!user) return null;

  return (
    <div className="flex items-center gap-4">
      {/* PulseBucks */}
      <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
        <Coins className="h-4 w-4 text-yellow-400" />
        <div>
          <div className="text-xs text-yellow-400/70">PulseBucks</div>
          <div className="text-sm font-bold text-yellow-400 font-mono">
            {formatNumber(user.pulseBucks)}
          </div>
        </div>
      </div>

      {/* Points */}
      <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-green-500/10 border border-green-500/20">
        <TrendingUp className="h-4 w-4 text-green-400" />
        <div>
          <div className="text-xs text-green-400/70">Points</div>
          <div className="text-sm font-bold text-green-400 font-mono">
            {formatNumber(user.points)}
          </div>
        </div>
      </div>
    </div>
  );
}
