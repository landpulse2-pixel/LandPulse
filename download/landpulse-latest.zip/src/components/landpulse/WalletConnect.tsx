'use client';

import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { useGameStore } from '@/store/gameStore';
import { Wallet, LogOut, Copy, Check, ChevronDown } from 'lucide-react';

// Phantom wallet type declaration
declare global {
  interface Window {
    solana?: {
      isPhantom?: boolean;
      isConnected?: boolean;
      publicKey?: {
        toString(): string;
      };
      connect(): Promise<{ publicKey: { toString(): string } }>;
      disconnect(): Promise<void>;
      on(event: string, callback: () => void): void;
      removeListener(event: string, callback: () => void): void;
    };
  }
}

export function WalletConnect() {
  const { isConnected, walletAddress, setConnected, setUser, setLoading } = useGameStore();
  const [copied, setCopied] = useState(false);
  const [phantomAvailable, setPhantomAvailable] = useState(false);

  useEffect(() => {
    // Check if Phantom is available
    const checkPhantom = () => {
      const available = typeof window !== 'undefined' && window.solana?.isPhantom;
      setPhantomAvailable(available || false);
    };

    checkPhantom();

    // Re-check after a short delay (in case wallet is still loading)
    const timeout = setTimeout(checkPhantom, 1000);
    return () => clearTimeout(timeout);
  }, []);

  // Auto-reconnect on page load
  useEffect(() => {
    const autoReconnect = async () => {
      if (phantomAvailable && window.solana?.isConnected) {
        try {
          const result = await window.solana.connect();
          const address = result.publicKey.toString();
          await connectUser(address);
        } catch (error) {
          console.error('Auto-reconnect failed:', error);
        }
      }
    };

    autoReconnect();

    // Listen for account changes
    if (phantomAvailable && window.solana) {
      window.solana.on('connect', () => {
        if (window.solana?.publicKey) {
          const address = window.solana.publicKey.toString();
          connectUser(address);
        }
      });

      window.solana.on('disconnect', () => {
        disconnectWallet();
      });
    }
  }, [phantomAvailable]);

  const connectUser = async (address: string) => {
    setLoading(true);
    try {
      const response = await fetch('/api/user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ walletAddress: address }),
      });

      const data = await response.json();
      if (data.user) {
        setUser(data.user);
        setConnected(true, address);
      }
    } catch (error) {
      console.error('Failed to connect user:', error);
    } finally {
      setLoading(false);
    }
  };

  const connectPhantom = async () => {
    if (!phantomAvailable) {
      // Open Phantom website to install
      window.open('https://phantom.app/', '_blank');
      return;
    }

    try {
      setLoading(true);
      const result = await window.solana!.connect();
      const address = result.publicKey.toString();
      await connectUser(address);
    } catch (error) {
      console.error('Failed to connect Phantom:', error);
    } finally {
      setLoading(false);
    }
  };

  const disconnectWallet = async () => {
    if (phantomAvailable && window.solana) {
      try {
        await window.solana.disconnect();
      } catch (error) {
        console.error('Failed to disconnect:', error);
      }
    }
    setUser(null);
    setConnected(false, null);
  };

  const copyAddress = () => {
    if (walletAddress) {
      navigator.clipboard.writeText(walletAddress);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const truncateAddress = (address: string) => {
    return `${address.slice(0, 4)}...${address.slice(-4)}`;
  };

  if (isConnected && walletAddress) {
    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button 
            variant="outline" 
            className="glass-card gradient-border border-0 hover:bg-purple-500/10"
          >
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="font-mono text-sm">
                {truncateAddress(walletAddress)}
              </span>
              <ChevronDown className="h-4 w-4 opacity-50" />
            </div>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent 
          align="end" 
          className="glass-card border-purple-500/20 bg-[#0f0f1a]/95"
        >
          <DropdownMenuItem 
            onClick={copyAddress}
            className="cursor-pointer hover:bg-purple-500/20"
          >
            {copied ? (
              <Check className="mr-2 h-4 w-4 text-green-500" />
            ) : (
              <Copy className="mr-2 h-4 w-4" />
            )}
            {copied ? 'Copied!' : 'Copy Address'}
          </DropdownMenuItem>
          <DropdownMenuItem 
            onClick={disconnectWallet}
            className="cursor-pointer hover:bg-red-500/20 text-red-400"
          >
            <LogOut className="mr-2 h-4 w-4" />
            Disconnect
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
  }

  return (
    <Button
      onClick={connectPhantom}
      className="gradient-bg hover:opacity-90 text-white font-semibold px-6"
    >
      <Wallet className="mr-2 h-4 w-4" />
      {phantomAvailable ? 'Connect Phantom' : 'Install Phantom'}
    </Button>
  );
}
