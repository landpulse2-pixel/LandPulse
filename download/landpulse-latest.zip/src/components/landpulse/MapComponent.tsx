'use client';

import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Parcel } from '@/store/gameStore';
import { GAME_CONFIG } from '@/lib/game-config';

// Fix Leaflet default marker icons
delete (L.Icon.Default.prototype as unknown as { _getIconUrl?: () => string })._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

// Custom marker icons for parcels
const createParcelIcon = (color: string, emoji: string) => {
  return L.divIcon({
    className: 'custom-parcel-marker',
    html: `
      <div style="
        background: ${color};
        width: 28px;
        height: 28px;
        border-radius: 50%;
        border: 2px solid white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.4);
        cursor: pointer;
      ">
        ${emoji}
      </div>
    `,
    iconSize: [28, 28],
    iconAnchor: [14, 14],
  });
};

interface MapComponentProps {
  center: [number, number];
  zoom: number;
  parcels: Parcel[];
  onMapClick: (lat: number, lng: number) => void;
  onParcelClick: (parcel: Parcel) => void;
  onMoveEnd: (center: [number, number], zoom: number) => void;
}

export default function MapComponent({
  center,
  zoom,
  parcels,
  onMapClick,
  onParcelClick,
  onMoveEnd,
}: MapComponentProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<L.Marker[]>([]);
  const parcelsLayerRef = useRef<L.LayerGroup | null>(null);

  // Initialize map
  useEffect(() => {
    if (!mapContainer.current || mapRef.current) return;

    const map = L.map(mapContainer.current, {
      center: [center[1], center[0]],
      zoom: zoom,
      minZoom: 2,
      maxZoom: 18,
      zoomControl: false,
    });

    // Use CartoDB Dark Matter tiles (free, no token needed)
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a> &copy; <a href="https://carto.com/">CARTO</a>',
      subdomains: 'abcd',
      maxZoom: 19,
    }).addTo(map);

    // Create layer group for parcels
    parcelsLayerRef.current = L.layerGroup().addTo(map);

    // Save map state on move
    map.on('moveend', () => {
      const c = map.getCenter();
      onMoveEnd([c.lng, c.lat], map.getZoom());
    });

    // Click handler for creating new parcels
    map.on('click', (e: L.LeafletMouseEvent) => {
      onMapClick(e.latlng.lat, e.latlng.lng);
    });

    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  // Update parcels on map
  useEffect(() => {
    if (!mapRef.current || !parcelsLayerRef.current) return;

    // Clear existing markers
    parcelsLayerRef.current.clearLayers();
    markersRef.current = [];

    // Add markers for each parcel
    parcels.forEach(parcel => {
      const rarityConfig = GAME_CONFIG.RARITY_LEVELS[parcel.level];
      const color = parcel.isOwnedByUser ? '#8b5cf6' : rarityConfig.color;
      const emoji = parcel.isOwnedByUser ? '🏠' : rarityConfig.emoji;
      
      const marker = L.marker([parcel.lat, parcel.lng], {
        icon: createParcelIcon(color, emoji),
      });

      // Popup content
      const popupContent = `
        <div style="
          background: rgba(15, 15, 25, 0.95);
          padding: 12px;
          border-radius: 8px;
          min-width: 160px;
          color: white;
          font-family: system-ui, sans-serif;
        ">
          <div style="font-weight: 600; margin-bottom: 4px;">${parcel.name}</div>
          <div style="
            display: inline-block;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 11px;
            background: ${color}20;
            color: ${color};
            border: 1px solid ${color}40;
            margin-bottom: 8px;
          ">
            ${rarityConfig.emoji} ${rarityConfig.name}
          </div>
          <div style="color: #facc15; font-weight: 600; font-size: 16px;">${parcel.price} PB</div>
          <div style="color: #22c55e; font-size: 11px; margin-top: 4px;">
            +${(parcel.pointsPerSecond * 86400).toFixed(0)} pts/jour
          </div>
        </div>
      `;

      marker.bindPopup(popupContent, {
        className: 'custom-popup',
      });

      marker.on('click', (e) => {
        L.DomEvent.stopPropagation(e);
        onParcelClick(parcel);
      });

      marker.addTo(parcelsLayerRef.current!);
      markersRef.current.push(marker);
    });
  }, [parcels, onParcelClick]);

  return (
    <div 
      ref={mapContainer} 
      className="h-[600px] w-full"
      style={{ background: '#0a0a15' }}
    />
  );
}
