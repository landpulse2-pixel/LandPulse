'use client';

import { useEffect, useState, useCallback } from 'react';
import { useGameStore, Building, Parcel } from '@/store/gameStore';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { GAME_CONFIG, formatNumber, pointsToDollarString } from '@/lib/game-config';
import { DailyBonus } from './DailyBonus';
import {
  Coins,
  TrendingUp,
  Building2,
  MapPin,
  Zap,
  Gift,
  Clock,
  Crown,
  Factory,
  Building as BuildingIcon,
  Home,
  Sparkles,
  ArrowUpRight,
  Wallet,
} from 'lucide-react';

export function Dashboard() {
  const { user, walletAddress, userParcels, buildings, updatePoints, setUser } = useGameStore();
  const [isLoading, setIsLoading] = useState(false);
  const [collectingBuilding, setCollectingBuilding] = useState<string | null>(null);

  // Fetch user data periodically to update points
  const fetchUserData = useCallback(async () => {
    if (!walletAddress) return;
    
    try {
      const response = await fetch(`/api/user?wallet=${walletAddress}`);
      const data = await response.json();
      if (data.user) {
        setUser(data.user);
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
    }
  }, [walletAddress, setUser]);

  useEffect(() => {
    fetchUserData();
    // Update every 10 seconds for real-time points
    const interval = setInterval(fetchUserData, 10000);
    return () => clearInterval(interval);
  }, [fetchUserData]);

  const handleCollectPoints = async (buildingId: string) => {
    if (!walletAddress) return;
    
    setCollectingBuilding(buildingId);
    try {
      const response = await fetch('/api/buildings/collect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ buildingId }),
      });

      const data = await response.json();
      if (response.ok) {
        updatePoints(data.collected);
        fetchUserData();
      }
    } catch (error) {
      console.error('Error collecting points:', error);
    } finally {
      setCollectingBuilding(null);
    }
  };

  // Calculate total income
  const totalPointsPerSecond = userParcels.reduce((sum, p) => sum + p.pointsPerSecond, 0);
  const totalPointsPerDay = totalPointsPerSecond * 86400;
  const totalPointsPerHour = totalPointsPerSecond * 3600;

  // Calculate boost status
  const hasBoost = user?.boostEndTime && new Date(user.boostEndTime) > new Date();
  const boostRemaining = hasBoost 
    ? Math.max(0, new Date(user.boostEndTime!).getTime() - Date.now())
    : 0;

  // Group parcels by rarity
  const parcelsByRarity = {
    common: userParcels.filter(p => p.level === 'common').length,
    rare: userParcels.filter(p => p.level === 'rare').length,
    epic: userParcels.filter(p => p.level === 'epic').length,
    legendary: userParcels.filter(p => p.level === 'legendary').length,
  };

  const getBuildingIcon = (type: string) => {
    switch (type) {
      case 'house': return <Home className="h-5 w-5" />;
      case 'office': return <BuildingIcon className="h-5 w-5" />;
      case 'factory': return <Factory className="h-5 w-5" />;
      case 'castle': return <Crown className="h-5 w-5" />;
      default: return <Building2 className="h-5 w-5" />;
    }
  };

  if (!user) {
    return (
      <div className="flex flex-col gap-4">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold gradient-text flex items-center gap-2">
            <Wallet className="h-6 w-6" />
            Tableau de Bord
          </h2>
          <p className="text-muted-foreground text-sm mt-1">
            Gérez vos actifs et collectez vos revenus
          </p>
        </div>
        <DailyBonus />
      </div>

      {/* Main Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* PulseBucks */}
        <Card className="glass-card border-yellow-500/20">
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-2">
              <Coins className="h-4 w-4 text-yellow-400" />
              PulseBucks
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-yellow-400">
              {formatNumber(user.pulseBucks)}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              Monnaie d'achat
            </div>
          </CardContent>
        </Card>

        {/* Points */}
        <Card className="glass-card border-green-500/20">
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-green-400" />
              Points
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-400">
              {formatNumber(user.points)}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              ≈ {pointsToDollarString(user.points)}
            </div>
          </CardContent>
        </Card>

        {/* Parcels */}
        <Card className="glass-card border-purple-500/20">
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-purple-400" />
              Parcelles
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold gradient-text">
              {userParcels.length}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              {userParcels.reduce((sum, p) => sum + p.price, 0)} PB valeur
            </div>
          </CardContent>
        </Card>

        {/* Income */}
        <Card className="glass-card border-cyan-500/20">
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-2">
              <Zap className="h-4 w-4 text-cyan-400" />
              Revenus/jour
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-cyan-400">
              +{formatNumber(totalPointsPerDay)}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              points par jour
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Boost Banner */}
      {hasBoost && (
        <Card className="glass-card border-orange-500/30 bg-orange-500/10">
          <CardContent className="flex items-center justify-between py-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-orange-500/20 flex items-center justify-center">
                <Zap className="h-5 w-5 text-orange-400" />
              </div>
              <div>
                <div className="font-semibold">Boost Actif x2</div>
                <div className="text-sm text-muted-foreground">
                  Reste {Math.floor(boostRemaining / 60000)} minutes
                </div>
              </div>
            </div>
            <Badge variant="outline" className="border-orange-500 text-orange-400">
              <Clock className="h-3 w-3 mr-1" />
              Actif
            </Badge>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Parcels by Rarity */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-purple-400" />
              Parcelles par Rareté
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {Object.entries(parcelsByRarity).map(([rarity, count]) => {
              const config = GAME_CONFIG.RARITY_LEVELS[rarity as keyof typeof GAME_CONFIG.RARITY_LEVELS];
              const percentage = userParcels.length > 0 ? (count / userParcels.length) * 100 : 0;
              
              return (
                <div key={rarity} className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <span>{config.emoji}</span>
                      <span>{config.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono">{count}</span>
                      <span className="text-muted-foreground">({percentage.toFixed(0)}%)</span>
                    </div>
                  </div>
                  <Progress 
                    value={percentage} 
                    className="h-2"
                    style={{ 
                      backgroundColor: `${config.color}20`,
                    }}
                  />
                </div>
              );
            })}
            
            {userParcels.length === 0 && (
              <div className="text-center py-6 text-muted-foreground">
                Aucune parcelle. Achetez-en sur la carte!
              </div>
            )}
          </CardContent>
        </Card>

        {/* Income Breakdown */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-400" />
              Revenus Détaillés
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="glass-card rounded-lg p-3">
                <div className="text-xs text-muted-foreground">Par seconde</div>
                <div className="text-lg font-semibold text-green-400">
                  {totalPointsPerSecond.toFixed(4)}
                </div>
              </div>
              <div className="glass-card rounded-lg p-3">
                <div className="text-xs text-muted-foreground">Par heure</div>
                <div className="text-lg font-semibold text-green-400">
                  {formatNumber(totalPointsPerHour)}
                </div>
              </div>
              <div className="glass-card rounded-lg p-3">
                <div className="text-xs text-muted-foreground">Par jour</div>
                <div className="text-lg font-semibold text-green-400">
                  {formatNumber(totalPointsPerDay)}
                </div>
              </div>
            </div>
            
            <Separator className="bg-purple-500/20" />
            
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Équivalent USD/jour</span>
                <span className="text-green-400">{pointsToDollarString(totalPointsPerDay)}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Points totaux gagnés</span>
                <span className="text-green-400">{formatNumber(user.totalPointsEarned)}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Total dépensé</span>
                <span className="text-yellow-400">{formatNumber(user.totalSpent)} PB</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Buildings Section */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Building2 className="h-5 w-5 text-cyan-400" />
            Vos Bâtiments
          </CardTitle>
          <CardDescription>
            Gérez vos bâtiments et collectez les revenus
          </CardDescription>
        </CardHeader>
        <CardContent>
          {buildings.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Building2 className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p>Aucun bâtiment construit.</p>
              <p className="text-sm">Construisez des bâtiments sur vos parcelles pour générer plus de revenus!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {buildings.map((building) => {
                const config = GAME_CONFIG.BUILDINGS[building.type as keyof typeof GAME_CONFIG.BUILDINGS];
                return (
                  <div 
                    key={building.id}
                    className="glass-card rounded-lg p-4 border border-purple-500/20"
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center text-xl">
                        {config?.emoji || '🏢'}
                      </div>
                      <div>
                        <div className="font-semibold">{building.name}</div>
                        <div className="text-xs text-muted-foreground">
                          +{formatNumber(building.pointsPerDay)} pts/jour
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="text-xs text-muted-foreground">
                        Capacité: {building.capacity} parcelle(s)
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleCollectPoints(building.id)}
                        disabled={collectingBuilding === building.id}
                        className="border-green-500/30 text-green-400 hover:bg-green-500/10"
                      >
                        {collectingBuilding === building.id ? (
                          '...'
                        ) : (
                          <>
                            <Coins className="h-3 w-3 mr-1" />
                            Collecter
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Purchase PulseBucks */}
      <Card className="glass-card border-yellow-500/20">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Gift className="h-5 w-5 text-yellow-400" />
            Acheter des PulseBucks
          </CardTitle>
          <CardDescription>
            Obtenez plus de PulseBucks pour agrandir votre empire
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {GAME_CONFIG.PB_PACKAGES.map((pkg, index) => (
              <Button
                key={index}
                variant="outline"
                className="h-auto py-4 flex-col glass-card hover:border-yellow-500/50"
              >
                <div className="text-xl font-bold text-yellow-400">{pkg.pb}</div>
                <div className="text-xs text-muted-foreground">PulseBucks</div>
                {pkg.bonus > 0 && (
                  <Badge variant="outline" className="mt-1 border-green-500 text-green-400 text-xs">
                    +{pkg.bonus} bonus
                  </Badge>
                )}
                <div className="mt-2 font-semibold">${pkg.price}</div>
              </Button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-4 text-center">
            Paiement par carte bancaire ou crypto (Phase 2)
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
