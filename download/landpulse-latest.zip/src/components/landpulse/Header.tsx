'use client';

import { useGameStore } from '@/store/gameStore';
import { WalletConnect } from './WalletConnect';
import { PulseBucksDisplay } from './PulseBucksDisplay';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  MapPin,
  LayoutDashboard,
  Calendar,
  Sparkles,
  TrendingUp,
} from 'lucide-react';

export function Header() {
  const { activeTab, setActiveTab, user, isConnected } = useGameStore();

  const tabs = [
    { id: 'map', label: 'Carte', icon: MapPin },
    { id: 'dashboard', label: 'Tableau de bord', icon: LayoutDashboard },
    { id: 'events', label: 'Événements', icon: Calendar },
  ] as const;

  return (
    <header className="sticky top-0 z-50 glass-card border-b border-purple-500/20">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg gradient-bg flex items-center justify-center pulse-glow">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold gradient-text">LandPulse</h1>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs border-purple-500/30">
                  Phase 1 Beta
                </Badge>
                <Badge variant="outline" className="text-xs border-green-500/30 text-green-400">
                  Solana
                </Badge>
              </div>
            </div>
          </div>

          {/* Navigation Tabs */}
          {isConnected && (
            <nav className="hidden md:flex items-center gap-1">
              {tabs.map((tab) => (
                <Button
                  key={tab.id}
                  variant={activeTab === tab.id ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setActiveTab(tab.id)}
                  className={activeTab === tab.id ? 'gradient-bg' : 'text-muted-foreground'}
                >
                  <tab.icon className="h-4 w-4 mr-2" />
                  {tab.label}
                </Button>
              ))}
            </nav>
          )}

          {/* Right Side */}
          <div className="flex items-center gap-4">
            {isConnected && user && (
              <>
                <PulseBucksDisplay />
                <Separator orientation="vertical" className="h-8 hidden sm:block bg-purple-500/20" />
              </>
            )}
            <WalletConnect />
          </div>
        </div>

        {/* Mobile Navigation */}
        {isConnected && (
          <nav className="md:hidden flex items-center justify-around py-2 border-t border-purple-500/20 -mx-4 px-4">
            {tabs.map((tab) => (
              <Button
                key={tab.id}
                variant={activeTab === tab.id ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setActiveTab(tab.id)}
                className={activeTab === tab.id ? 'gradient-bg' : 'text-muted-foreground'}
              >
                <tab.icon className="h-4 w-4" />
              </Button>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
}
