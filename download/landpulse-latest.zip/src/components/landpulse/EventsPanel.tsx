'use client';

import { useState, useEffect } from 'react';
import { useGameStore } from '@/store/gameStore';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { GAME_CONFIG } from '@/lib/game-config';
import {
  Calendar,
  Trophy,
  Target,
  TrendingUp,
  Clock,
  Users,
  Zap,
  Gift,
  Loader2,
} from 'lucide-react';

interface Event {
  id: string;
  type: string;
  name: string;
  description: string;
  reward: number;
  participants: number;
  endTime: string;
  status: 'active' | 'upcoming' | 'ended';
}

// Mock events data
const mockEvents: Event[] = [
  {
    id: '1',
    type: 'quiz',
    name: 'Quiz Crypto',
    description: 'Testez vos connaissances en crypto et blockchain',
    reward: 50,
    participants: 1234,
    endTime: new Date(Date.now() + 3600000 * 24).toISOString(),
    status: 'active',
  },
  {
    id: '2',
    type: 'prediction',
    name: 'Prédiction SOL',
    description: 'Prédisez le prix du SOL dans 24h',
    reward: 100,
    participants: 567,
    endTime: new Date(Date.now() + 3600000 * 48).toISOString(),
    status: 'active',
  },
  {
    id: '3',
    type: 'challenge',
    name: 'Défi Construction',
    description: 'Construisez 5 bâtiments cette semaine',
    reward: 200,
    participants: 89,
    endTime: new Date(Date.now() + 3600000 * 72).toISOString(),
    status: 'active',
  },
];

export function EventsPanel() {
  const { user } = useGameStore();
  const [events, setEvents] = useState<Event[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [participating, setParticipating] = useState<string | null>(null);

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setEvents(mockEvents);
      setIsLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const handleParticipate = async (eventId: string) => {
    setParticipating(eventId);
    // Simulate participation
    await new Promise(resolve => setTimeout(resolve, 1500));
    setParticipating(null);
  };

  const getTimeRemaining = (endTime: string) => {
    const end = new Date(endTime).getTime();
    const now = Date.now();
    const diff = end - now;
    
    if (diff <= 0) return 'Terminé';
    
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    if (days > 0) return `${days}j ${hours}h`;
    return `${hours}h`;
  };

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'quiz': return <Target className="h-5 w-5" />;
      case 'prediction': return <TrendingUp className="h-5 w-5" />;
      case 'challenge': return <Trophy className="h-5 w-5" />;
      default: return <Calendar className="h-5 w-5" />;
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col gap-4">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-48 rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold gradient-text flex items-center gap-2">
            <Calendar className="h-6 w-6" />
            Événements
          </h2>
          <p className="text-muted-foreground text-sm mt-1">
            Participez aux événements pour gagner des récompenses
          </p>
        </div>
        <Badge variant="outline" className="border-purple-500/30">
          <Zap className="h-3 w-3 mr-1 text-yellow-400" />
          {events.filter(e => e.status === 'active').length} actifs
        </Badge>
      </div>

      {/* Events Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {events.map((event) => (
          <Card key={event.id} className="glass-card border-purple-500/20 hover:border-purple-500/40 transition-all">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center text-purple-400">
                  {getEventIcon(event.type)}
                </div>
                <Badge 
                  variant="outline" 
                  className={event.status === 'active' ? 'border-green-500/30 text-green-400' : 'border-muted text-muted-foreground'}
                >
                  {event.status === 'active' ? 'Actif' : 'À venir'}
                </Badge>
              </div>
              <CardTitle className="text-lg mt-3">{event.name}</CardTitle>
              <CardDescription>{event.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Gift className="h-4 w-4 text-yellow-400" />
                  <span>Récompense</span>
                </div>
                <span className="font-semibold text-yellow-400">{event.reward} PB</span>
              </div>
              
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Users className="h-4 w-4" />
                  <span>Participants</span>
                </div>
                <span className="font-mono">{event.participants.toLocaleString()}</span>
              </div>

              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  <span>Temps restant</span>
                </div>
                <span className="font-mono text-cyan-400">{getTimeRemaining(event.endTime)}</span>
              </div>

              <Button
                onClick={() => handleParticipate(event.id)}
                disabled={participating === event.id || event.status !== 'active'}
                className="w-full gradient-bg"
              >
                {participating === event.id ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Chargement...
                  </>
                ) : (
                  'Participer'
                )}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Info Card */}
      <Card className="glass-card border-cyan-500/20">
        <CardContent className="py-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center flex-shrink-0">
              <Trophy className="h-5 w-5 text-cyan-400" />
            </div>
            <div>
              <h3 className="font-semibold">Classements & Récompenses</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Les joueurs les plus actifs et les meilleurs prédicteurs remportent des bonus supplémentaires. 
                Restez connecté pour ne pas manquer les événements spéciaux!
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
