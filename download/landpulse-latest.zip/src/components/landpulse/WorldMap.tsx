'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { useGameStore, Parcel } from '@/store/gameStore';
import { ParcelModal } from './ParcelModal';
import { Skeleton } from '@/components/ui/skeleton';
import { GAME_CONFIG, getRandomRarity, calculateParcelPrice, generateParcelName } from '@/lib/game-config';
import { MapPin, ZoomIn, ZoomOut, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

// Dynamically import Leaflet components (client-side only)
import dynamic from 'next/dynamic';

const MapComponent = dynamic(() => import('./MapComponent'), {
  ssr: false,
  loading: () => (
    <div className="h-[600px] w-full rounded-lg glass-card flex items-center justify-center">
      <Loader2 className="h-8 w-8 animate-spin text-purple-500" />
    </div>
  ),
});

export function WorldMap() {
  const { 
    walletAddress, 
    userParcels, 
    setUserParcels, 
    setSelectedParcel, 
    isLoading, 
    setLoading,
    mapCenter,
    mapZoom,
    setMapCenter,
    setMapZoom
  } = useGameStore();
  
  const [mapLoaded, setMapLoaded] = useState(false);

  // Fetch user parcels
  const fetchUserParcels = useCallback(async () => {
    if (!walletAddress) return;
    
    setLoading(true);
    try {
      const response = await fetch(`/api/parcels?wallet=${walletAddress}`);
      const data = await response.json();
      setUserParcels(data.parcels || []);
    } catch (error) {
      console.error('Error fetching parcels:', error);
    } finally {
      setLoading(false);
    }
  }, [walletAddress, setUserParcels, setLoading]);

  useEffect(() => {
    fetchUserParcels();
    setMapLoaded(true);
  }, [fetchUserParcels]);

  // Handle parcel creation from map click
  const handleMapClick = useCallback((lat: number, lng: number) => {
    const rarity = getRandomRarity();
    const price = calculateParcelPrice(lat, lng);
    const name = generateParcelName(lat, lng);
    const rarityConfig = GAME_CONFIG.RARITY_LEVELS[rarity];
    
    const newParcel: Parcel = {
      id: `temp-${Date.now()}`,
      lat,
      lng,
      level: rarity,
      price,
      name,
      pointsPerSecond: (rarityConfig.incomeMultiplier * 0.001),
      improvementLevel: 0,
      isOwned: false,
      isOwnedByUser: false,
    };
    
    setSelectedParcel(newParcel);
  }, [setSelectedParcel]);

  if (isLoading && !mapLoaded) {
    return (
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-8 w-32" />
        </div>
        <Skeleton className="h-[600px] w-full rounded-lg" />
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      {/* Map Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold gradient-text flex items-center gap-2">
            <MapPin className="h-6 w-6" />
            Carte du Monde
          </h2>
          <p className="text-muted-foreground text-sm mt-1">
            Cliquez sur la carte pour acheter une parcelle
          </p>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          {Object.entries(GAME_CONFIG.RARITY_LEVELS).map(([key, config]) => (
            <div key={key} className="flex items-center gap-1">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: config.color }}
              />
              <span className="text-muted-foreground">{config.emoji}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Map Container */}
      <div className="relative rounded-lg overflow-hidden glass-card border border-purple-500/20">
        {isLoading && (
          <div className="absolute inset-0 bg-background/80 flex items-center justify-center z-[1000]">
            <Loader2 className="h-8 w-8 animate-spin text-purple-500" />
          </div>
        )}
        
        <MapComponent
          center={mapCenter}
          zoom={mapZoom}
          parcels={userParcels}
          onMapClick={handleMapClick}
          onParcelClick={setSelectedParcel}
          onMoveEnd={(center, zoom) => {
            setMapCenter(center);
            setMapZoom(zoom);
          }}
        />

        {/* Coordinates Display */}
        <div className="absolute top-4 left-4 glass-card rounded-lg px-3 py-1 text-xs text-muted-foreground z-[1000]">
          Lat: {mapCenter[1].toFixed(4)}° | Lng: {mapCenter[0].toFixed(4)}° | Zoom: {mapZoom.toFixed(1)}x
        </div>

        {/* Instructions */}
        <div className="absolute bottom-4 right-4 glass-card rounded-lg px-3 py-2 text-xs text-muted-foreground z-[1000]">
          💡 Cliquez n&apos;importe où pour acheter une parcelle
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="glass-card rounded-lg p-4 text-center">
          <div className="text-2xl font-bold gradient-text">
            {userParcels.length}
          </div>
          <div className="text-xs text-muted-foreground">Vos parcelles</div>
        </div>
        <div className="glass-card rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-green-400">
            {userParcels.filter(p => p.level === 'legendary' || p.level === 'epic').length}
          </div>
          <div className="text-xs text-muted-foreground">Premium</div>
        </div>
        <div className="glass-card rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-yellow-400">
            {userParcels.reduce((sum, p) => sum + p.price, 0)}
          </div>
          <div className="text-xs text-muted-foreground">Valeur totale (PB)</div>
        </div>
        <div className="glass-card rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-purple-400">
            {userParcels.reduce((sum, p) => sum + (p.buildings?.length || 0), 0)}
          </div>
          <div className="text-xs text-muted-foreground">Bâtiments</div>
        </div>
      </div>

      {/* Parcel Modal */}
      <ParcelModal onRefresh={fetchUserParcels} />
    </div>
  );
}
