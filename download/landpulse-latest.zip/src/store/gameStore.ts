import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Parcel {
  id: string;
  lat: number;
  lng: number;
  level: 'common' | 'rare' | 'epic' | 'legendary';
  price: number;
  name: string;
  pointsPerSecond: number;
  ownerId?: string;
  ownerWallet?: string;
  buildings?: Building[];
  improvementLevel: number;
  isOwnedByUser?: boolean;
  isOwned?: boolean;
}

export interface Building {
  id: string;
  type: 'house' | 'office' | 'factory' | 'castle';
  name: string;
  price: number;
  pointsPerDay: number;
  capacity: number;
  boostPercent: number;
  parcelId?: string;
  ownerId: string;
  level: number;
  lastCollected: string;
  assignedParcels?: string[];
}

export interface User {
  id: string;
  walletAddress: string;
  pulseBucks: number;
  points: number;
  totalPointsEarned: number;
  lastDailyBonus?: string;
  totalEarned: number;
  totalSpent: number;
  boostEndTime?: string;
}

interface GameState {
  // User
  user: User | null;
  isConnected: boolean;
  walletAddress: string | null;
  
  // Parcels
  parcels: Parcel[];
  userParcels: Parcel[];
  selectedParcel: Parcel | null;
  
  // Buildings
  buildings: Building[];
  
  // UI State
  isLoading: boolean;
  showParcelModal: boolean;
  showBuildingPanel: boolean;
  activeTab: 'map' | 'dashboard' | 'events';
  mapView: 'globe' | 'mapbox';
  
  // Map state
  mapCenter: [number, number];
  mapZoom: number;
  
  // Actions
  setUser: (user: User | null) => void;
  setConnected: (connected: boolean, address?: string | null) => void;
  setParcels: (parcels: Parcel[]) => void;
  setUserParcels: (parcels: Parcel[]) => void;
  setSelectedParcel: (parcel: Parcel | null) => void;
  setBuildings: (buildings: Building[]) => void;
  updatePulseBucks: (amount: number) => void;
  updatePoints: (amount: number) => void;
  setLoading: (loading: boolean) => void;
  setShowParcelModal: (show: boolean) => void;
  setShowBuildingPanel: (show: boolean) => void;
  setActiveTab: (tab: 'map' | 'dashboard' | 'events') => void;
  setMapView: (view: 'globe' | 'mapbox') => void;
  setMapCenter: (center: [number, number]) => void;
  setMapZoom: (zoom: number) => void;
  addParcel: (parcel: Parcel) => void;
  addBuilding: (building: Building) => void;
  reset: () => void;
}

const initialState = {
  user: null,
  isConnected: false,
  walletAddress: null,
  parcels: [],
  userParcels: [],
  selectedParcel: null,
  buildings: [],
  isLoading: false,
  showParcelModal: false,
  showBuildingPanel: false,
  activeTab: 'map' as const,
  mapView: 'mapbox' as const,
  mapCenter: [0, 20] as [number, number],
  mapZoom: 2,
};

export const useGameStore = create<GameState>()(
  persist(
    (set) => ({
      ...initialState,
      
      setUser: (user) => set({ user }),
      
      setConnected: (connected, address = null) => set({ 
        isConnected: connected, 
        walletAddress: address 
      }),
      
      setParcels: (parcels) => set({ parcels }),
      
      setUserParcels: (userParcels) => set({ userParcels }),
      
      setSelectedParcel: (parcel) => set({ selectedParcel: parcel }),
      
      setBuildings: (buildings) => set({ buildings }),
      
      updatePulseBucks: (amount) => set((state) => ({
        user: state.user 
          ? { ...state.user, pulseBucks: state.user.pulseBucks + amount }
          : null
      })),
      
      updatePoints: (amount) => set((state) => ({
        user: state.user 
          ? { ...state.user, points: state.user.points + amount, totalPointsEarned: state.user.totalPointsEarned + (amount > 0 ? amount : 0) }
          : null
      })),
      
      setLoading: (isLoading) => set({ isLoading }),
      
      setShowParcelModal: (showParcelModal) => set({ showParcelModal }),
      
      setShowBuildingPanel: (showBuildingPanel) => set({ showBuildingPanel }),
      
      setActiveTab: (activeTab) => set({ activeTab }),
      
      setMapView: (mapView) => set({ mapView }),
      
      setMapCenter: (mapCenter) => set({ mapCenter }),
      
      setMapZoom: (mapZoom) => set({ mapZoom }),
      
      addParcel: (parcel) => set((state) => ({
        parcels: [...state.parcels, parcel],
        userParcels: parcel.isOwnedByUser 
          ? [...state.userParcels, parcel]
          : state.userParcels
      })),
      
      addBuilding: (building) => set((state) => ({
        buildings: [...state.buildings, building]
      })),
      
      reset: () => set(initialState),
    }),
    {
      name: 'landpulse-storage',
      partialize: (state) => ({
        walletAddress: state.walletAddress,
        isConnected: state.isConnected,
        mapView: state.mapView,
      }),
    }
  )
);
