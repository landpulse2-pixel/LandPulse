import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Parcel {
  id: string;
  x: number;
  y: number;
  price: number;
  name: string;
  region: string;
  description?: string;
  ownerId?: string;
  buildings?: Building[];
}

export interface Building {
  id: string;
  type: string;
  name: string;
  price: number;
  income: number;
  parcelId: string;
  ownerId: string;
  level: number;
  lastCollected: string;
}

export interface User {
  id: string;
  walletAddress: string;
  pulseBucks: number;
  lastDailyBonus?: string;
  totalEarned: number;
  totalSpent: number;
}

interface GameState {
  // User
  user: User | null;
  isConnected: boolean;
  walletAddress: string | null;
  
  // Parcels
  parcels: Parcel[];
  selectedParcel: Parcel | null;
  
  // Buildings
  buildings: Building[];
  
  // UI State
  isLoading: boolean;
  showParcelModal: boolean;
  showBuildingPanel: boolean;
  activeTab: 'map' | 'dashboard' | 'events';
  
  // Actions
  setUser: (user: User | null) => void;
  setConnected: (connected: boolean, address?: string | null) => void;
  setParcels: (parcels: Parcel[]) => void;
  setSelectedParcel: (parcel: Parcel | null) => void;
  setBuildings: (buildings: Building[]) => void;
  updatePulseBucks: (amount: number) => void;
  setLoading: (loading: boolean) => void;
  setShowParcelModal: (show: boolean) => void;
  setShowBuildingPanel: (show: boolean) => void;
  setActiveTab: (tab: 'map' | 'dashboard' | 'events') => void;
  addParcel: (parcel: Parcel) => void;
  addBuilding: (building: Building) => void;
  reset: () => void;
}

const initialState = {
  user: null,
  isConnected: false,
  walletAddress: null,
  parcels: [],
  selectedParcel: null,
  buildings: [],
  isLoading: false,
  showParcelModal: false,
  showBuildingPanel: false,
  activeTab: 'map' as const,
};

export const useGameStore = create<GameState>()(
  persist(
    (set) => ({
      ...initialState,
      
      setUser: (user) => set({ user }),
      
      setConnected: (connected, address = null) => set({ 
        isConnected: connected, 
        walletAddress: address 
      }),
      
      setParcels: (parcels) => set({ parcels }),
      
      setSelectedParcel: (parcel) => set({ selectedParcel: parcel }),
      
      setBuildings: (buildings) => set({ buildings }),
      
      updatePulseBucks: (amount) => set((state) => ({
        user: state.user 
          ? { ...state.user, pulseBucks: state.user.pulseBucks + amount }
          : null
      })),
      
      setLoading: (isLoading) => set({ isLoading }),
      
      setShowParcelModal: (showParcelModal) => set({ showParcelModal }),
      
      setShowBuildingPanel: (showBuildingPanel) => set({ showBuildingPanel }),
      
      setActiveTab: (activeTab) => set({ activeTab }),
      
      addParcel: (parcel) => set((state) => ({
        parcels: [...state.parcels, parcel]
      })),
      
      addBuilding: (building) => set((state) => ({
        buildings: [...state.buildings, building]
      })),
      
      reset: () => set(initialState),
    }),
    {
      name: 'landpulse-storage',
      partialize: (state) => ({
        walletAddress: state.walletAddress,
        isConnected: state.isConnected,
      }),
    }
  )
);
