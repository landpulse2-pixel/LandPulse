import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { GAME_CONFIG, getRegionByCoords, calculateParcelPrice, generateParcelName } from '@/lib/game-config';

// GET /api/parcels - Get all parcels
export async function GET(request: NextRequest) {
  try {
    const walletAddress = request.nextUrl.searchParams.get('wallet');
    
    // Get all existing parcels from database
    const existingParcels = await prisma.parcel.findMany({
      include: {
        buildings: true,
        owner: {
          select: {
            walletAddress: true,
          },
        },
      },
    });
    
    // Create a map for quick lookup
    const parcelMap = new Map(
      existingParcels.map(p => [`${p.x}-${p.y}`, p])
    );
    
    // Generate all parcels for the grid
    const allParcels = [];
    for (let x = 0; x < GAME_CONFIG.GRID_SIZE; x++) {
      for (let y = 0; y < GAME_CONFIG.GRID_SIZE; y++) {
        const key = `${x}-${y}`;
        const existing = parcelMap.get(key);
        
        if (existing) {
          allParcels.push({
            ...existing,
            isOwned: !!existing.ownerId,
            isOwnedByUser: existing.owner?.walletAddress === walletAddress,
          });
        } else {
          // Generate virtual parcel
          const region = getRegionByCoords(x, y);
          const price = calculateParcelPrice(x, y);
          const name = generateParcelName(x, y, region.name);
          
          allParcels.push({
            id: `virtual-${x}-${y}`,
            x,
            y,
            price,
            name,
            region: region.name,
            description: region.description,
            ownerId: null,
            owner: null,
            buildings: [],
            isOwned: false,
            isOwnedByUser: false,
            isVirtual: true,
          });
        }
      }
    }
    
    // Also get user's parcels if wallet provided
    let userParcels = [];
    if (walletAddress) {
      userParcels = existingParcels.filter(
        p => p.owner?.walletAddress === walletAddress
      );
    }
    
    return NextResponse.json({ 
      parcels: allParcels,
      userParcels,
      gridSize: GAME_CONFIG.GRID_SIZE,
    });
  } catch (error) {
    console.error('Error fetching parcels:', error);
    return NextResponse.json(
      { error: 'Failed to fetch parcels' },
      { status: 500 }
    );
  }
}
