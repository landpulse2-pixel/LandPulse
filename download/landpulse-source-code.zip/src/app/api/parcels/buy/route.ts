import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getRegionByCoords, calculateParcelPrice, generateParcelName } from '@/lib/game-config';

// POST /api/parcels/buy - Buy a parcel
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { walletAddress, x, y } = body;
    
    if (!walletAddress || x === undefined || y === undefined) {
      return NextResponse.json(
        { error: 'Wallet address and coordinates required' },
        { status: 400 }
      );
    }
    
    // Get user
    const user = await prisma.user.findUnique({
      where: { walletAddress },
    });
    
    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }
    
    // Check if parcel already exists and is owned
    const existingParcel = await prisma.parcel.findFirst({
      where: { x, y },
    });
    
    if (existingParcel && existingParcel.ownerId) {
      return NextResponse.json(
        { error: 'Parcel already owned' },
        { status: 400 }
      );
    }
    
    // Calculate price
    const price = calculateParcelPrice(x, y);
    
    // Check if user has enough PulseBucks
    if (user.pulseBucks < price) {
      return NextResponse.json(
        { error: 'Insufficient PulseBucks', required: price, current: user.pulseBucks },
        { status: 400 }
      );
    }
    
    // Get region info
    const region = getRegionByCoords(x, y);
    const name = generateParcelName(x, y, region.name);
    
    // Create or update parcel and deduct PulseBucks
    const parcel = await prisma.parcel.upsert({
      where: {
        x_y: { x, y },
      },
      create: {
        x,
        y,
        price,
        name,
        region: region.name,
        description: region.description,
        ownerId: user.id,
      },
      update: {
        ownerId: user.id,
      },
    });
    
    // Update user balance
    const updatedUser = await prisma.user.update({
      where: { walletAddress },
      data: {
        pulseBucks: user.pulseBucks - price,
        totalSpent: user.totalSpent + price,
      },
    });
    
    return NextResponse.json({ 
      success: true,
      parcel,
      newBalance: updatedUser.pulseBucks,
      user: updatedUser,
    });
  } catch (error) {
    console.error('Error buying parcel:', error);
    return NextResponse.json(
      { error: 'Failed to buy parcel' },
      { status: 500 }
    );
  }
}
