import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { GAME_CONFIG } from '@/lib/game-config';

// POST /api/user/daily-bonus - Claim daily bonus
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { walletAddress } = body;
    
    if (!walletAddress) {
      return NextResponse.json(
        { error: 'Wallet address required' },
        { status: 400 }
      );
    }
    
    const user = await db.user.findUnique({
      where: { walletAddress },
    });
    
    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }
    
    // Check if bonus already claimed today
    const now = new Date();
    const lastBonus = user.lastDailyBonus;
    
    if (lastBonus) {
      const timeSinceLastBonus = now.getTime() - new Date(lastBonus).getTime();
      
      if (timeSinceLastBonus < GAME_CONFIG.DAILY_BONUS_COOLDOWN) {
        const remainingTime = GAME_CONFIG.DAILY_BONUS_COOLDOWN - timeSinceLastBonus;
        const hours = Math.floor(remainingTime / (1000 * 60 * 60));
        const minutes = Math.floor((remainingTime % (1000 * 60 * 60)) / (1000 * 60));
        
        return NextResponse.json(
          { 
            error: 'Bonus already claimed',
            remainingTime,
            message: `Come back in ${hours}h ${minutes}m` 
          },
          { status: 400 }
        );
      }
    }
    
    // Update user with bonus
    const updatedUser = await db.user.update({
      where: { walletAddress },
      data: {
        pulseBucks: user.pulseBucks + GAME_CONFIG.DAILY_BONUS,
        totalEarned: user.totalEarned + GAME_CONFIG.DAILY_BONUS,
        lastDailyBonus: now,
      },
    });
    
    return NextResponse.json({ 
      success: true,
      bonus: GAME_CONFIG.DAILY_BONUS,
      newBalance: updatedUser.pulseBucks,
      user: updatedUser,
    });
  } catch (error) {
    console.error('Error claiming daily bonus:', error);
    return NextResponse.json(
      { error: 'Failed to claim daily bonus' },
      { status: 500 }
    );
  }
}
