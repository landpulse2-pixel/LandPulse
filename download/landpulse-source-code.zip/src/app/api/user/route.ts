import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { GAME_CONFIG } from '@/lib/game-config';

// GET /api/user - Get user info by wallet address
export async function GET(request: NextRequest) {
  try {
    const walletAddress = request.nextUrl.searchParams.get('wallet');
    
    if (!walletAddress) {
      return NextResponse.json(
        { error: 'Wallet address required' },
        { status: 400 }
      );
    }
    
    let user = await db.user.findUnique({
      where: { walletAddress },
      include: {
        parcels: {
          include: {
            buildings: true,
          },
        },
        buildings: true,
      },
    });
    
    if (!user) {
      // Create new user with initial PulseBucks
      user = await db.user.create({
        data: {
          walletAddress,
          pulseBucks: GAME_CONFIG.INITIAL_PULSE_BUCKS,
        },
        include: {
          parcels: {
            include: {
              buildings: true,
            },
          },
          buildings: true,
        },
      });
    }
    
    return NextResponse.json({ user });
  } catch (error) {
    console.error('Error fetching user:', error);
    return NextResponse.json(
      { error: 'Failed to fetch user' },
      { status: 500 }
    );
  }
}

// POST /api/user - Connect/Create user
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { walletAddress } = body;
    
    if (!walletAddress) {
      return NextResponse.json(
        { error: 'Wallet address required' },
        { status: 400 }
      );
    }
    
    let user = await db.user.findUnique({
      where: { walletAddress },
      include: {
        parcels: {
          include: {
            buildings: true,
          },
        },
        buildings: true,
      },
    });
    
    if (!user) {
      user = await db.user.create({
        data: {
          walletAddress,
          pulseBucks: GAME_CONFIG.INITIAL_PULSE_BUCKS,
        },
        include: {
          parcels: {
            include: {
              buildings: true,
            },
          },
          buildings: true,
        },
      });
    }
    
    return NextResponse.json({ user, isNew: !user });
  } catch (error) {
    console.error('Error connecting user:', error);
    return NextResponse.json(
      { error: 'Failed to connect user' },
      { status: 500 }
    );
  }
}
