import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

// POST /api/buildings/collect - Collect income from buildings
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { walletAddress, buildingId } = body;
    
    if (!walletAddress) {
      return NextResponse.json(
        { error: 'Wallet address required' },
        { status: 400 }
      );
    }
    
    // Get user
    const user = await prisma.user.findUnique({
      where: { walletAddress },
    });
    
    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }
    
    const now = new Date();
    
    if (buildingId) {
      // Collect from specific building
      const building = await prisma.building.findFirst({
        where: {
          id: buildingId,
          ownerId: user.id,
        },
      });
      
      if (!building) {
        return NextResponse.json(
          { error: 'Building not found or not owned by user' },
          { status: 400 }
        );
      }
      
      // Calculate income
      const lastCollected = new Date(building.lastCollected);
      const hoursSinceCollection = (now.getTime() - lastCollected.getTime()) / (1000 * 60 * 60);
      const income = Math.floor(hoursSinceCollection * building.income);
      
      if (income <= 0) {
        return NextResponse.json(
          { error: 'No income to collect yet' },
          { status: 400 }
        );
      }
      
      // Update building last collected time
      await prisma.building.update({
        where: { id: building.id },
        data: { lastCollected: now },
      });
      
      // Update user balance
      const updatedUser = await prisma.user.update({
        where: { walletAddress },
        data: {
          pulseBucks: user.pulseBucks + income,
          totalEarned: user.totalEarned + income,
        },
      });
      
      return NextResponse.json({ 
        success: true,
        collected: income,
        newBalance: updatedUser.pulseBucks,
        user: updatedUser,
      });
    } else {
      // Collect from all buildings
      const buildings = await prisma.building.findMany({
        where: {
          ownerId: user.id,
        },
      });
      
      let totalIncome = 0;
      
      for (const building of buildings) {
        const lastCollected = new Date(building.lastCollected);
        const hoursSinceCollection = (now.getTime() - lastCollected.getTime()) / (1000 * 60 * 60);
        const income = Math.floor(hoursSinceCollection * building.income);
        
        if (income > 0) {
          totalIncome += income;
          
          await prisma.building.update({
            where: { id: building.id },
            data: { lastCollected: now },
          });
        }
      }
      
      if (totalIncome <= 0) {
        return NextResponse.json(
          { error: 'No income to collect yet' },
          { status: 400 }
        );
      }
      
      // Update user balance
      const updatedUser = await prisma.user.update({
        where: { walletAddress },
        data: {
          pulseBucks: user.pulseBucks + totalIncome,
          totalEarned: user.totalEarned + totalIncome,
        },
      });
      
      return NextResponse.json({ 
        success: true,
        collected: totalIncome,
        buildingsUpdated: buildings.length,
        newBalance: updatedUser.pulseBucks,
        user: updatedUser,
      });
    }
  } catch (error) {
    console.error('Error collecting income:', error);
    return NextResponse.json(
      { error: 'Failed to collect income' },
      { status: 500 }
    );
  }
}
