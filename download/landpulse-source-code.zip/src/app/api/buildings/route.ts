import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { GAME_CONFIG } from '@/lib/game-config';

// GET /api/buildings - Get user's buildings
export async function GET(request: NextRequest) {
  try {
    const walletAddress = request.nextUrl.searchParams.get('wallet');
    
    if (!walletAddress) {
      return NextResponse.json(
        { error: 'Wallet address required' },
        { status: 400 }
      );
    }
    
    const buildings = await prisma.building.findMany({
      where: {
        owner: {
          walletAddress,
        },
      },
      include: {
        parcel: true,
      },
    });
    
    // Calculate pending income for each building
    const buildingsWithIncome = buildings.map(building => {
      const now = new Date();
      const lastCollected = new Date(building.lastCollected);
      const hoursSinceCollection = (now.getTime() - lastCollected.getTime()) / (1000 * 60 * 60);
      const pendingIncome = Math.floor(hoursSinceCollection * building.income);
      
      return {
        ...building,
        pendingIncome,
        hoursSinceCollection: Math.floor(hoursSinceCollection * 10) / 10,
      };
    });
    
    // Calculate total pending income
    const totalPendingIncome = buildingsWithIncome.reduce(
      (sum, b) => sum + b.pendingIncome, 
      0
    );
    
    // Get building types config
    const buildingTypes = Object.entries(GAME_CONFIG.BUILDINGS).map(([key, value]) => ({
      type: key,
      ...value,
    }));
    
    return NextResponse.json({ 
      buildings: buildingsWithIncome,
      totalPendingIncome,
      buildingTypes,
    });
  } catch (error) {
    console.error('Error fetching buildings:', error);
    return NextResponse.json(
      { error: 'Failed to fetch buildings' },
      { status: 500 }
    );
  }
}
