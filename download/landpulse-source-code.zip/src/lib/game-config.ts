// LandPulse Game Configuration

export const GAME_CONFIG = {
  // Grid settings
  GRID_SIZE: 20, // 20x20 grid
  
  // Initial PulseBucks for new users
  INITIAL_PULSE_BUCKS: 100,
  
  // Daily bonus
  DAILY_BONUS: 10,
  DAILY_BONUS_COOLDOWN: 24 * 60 * 60 * 1000, // 24 hours in ms
  
  // Parcel settings
  PARCEL_BASE_PRICE: 50,
  PARCEL_PRICE_INCREMENT: 5, // Price increases by location
  
  // Regions
  REGIONS: [
    { name: 'North America', color: '#3b82f6', description: 'The tech hub of the virtual world' },
    { name: 'Europe', color: '#8b5cf6', description: 'Rich history meets modern innovation' },
    { name: 'Asia', color: '#ec4899', description: 'Ancient traditions and future tech' },
    { name: 'Africa', color: '#f59e0b', description: 'Untapped potential and resources' },
    { name: 'South America', color: '#10b981', description: 'Natural wonders and opportunities' },
    { name: 'Oceania', color: '#06b6d4', description: 'Island paradise with hidden gems' },
  ],
  
  // Building types
  BUILDINGS: {
    house: {
      name: 'House',
      emoji: '🏠',
      price: 50,
      income: 2,
      description: 'A cozy home that generates passive income',
    },
    farm: {
      name: 'Farm',
      emoji: '🌾',
      price: 100,
      income: 5,
      description: 'Agricultural land that produces steady returns',
    },
    factory: {
      name: 'Factory',
      emoji: '🏭',
      price: 250,
      income: 12,
      description: 'Industrial complex for higher yields',
    },
    tower: {
      name: 'Tower',
      emoji: '🏢',
      price: 500,
      income: 25,
      description: 'Commercial tower with premium income',
    },
    castle: {
      name: 'Castle',
      emoji: '🏰',
      price: 1000,
      income: 60,
      description: 'Royal estate with maximum earnings',
    },
  },
  
  // Event types
  EVENT_TYPES: {
    quiz: {
      name: 'Quiz Challenge',
      description: 'Answer questions to earn rewards',
      baseReward: 20,
    },
    prediction: {
      name: 'SOL Prediction',
      description: 'Predict SOL price movements',
      baseReward: 30,
    },
    challenge: {
      name: 'Daily Challenge',
      description: 'Complete special tasks',
      baseReward: 25,
    },
  },
} as const;

// Helper function to get region based on coordinates
export function getRegionByCoords(x: number, y: number): typeof GAME_CONFIG.REGIONS[number] {
  const regions = GAME_CONFIG.REGIONS;
  const regionIndex = Math.floor((x + y) / (GAME_CONFIG.GRID_SIZE / regions.length)) % regions.length;
  return regions[regionIndex];
}

// Helper function to calculate parcel price
export function calculateParcelPrice(x: number, y: number): number {
  const centerDistance = Math.sqrt(
    Math.pow(x - GAME_CONFIG.GRID_SIZE / 2, 2) + 
    Math.pow(y - GAME_CONFIG.GRID_SIZE / 2, 2)
  );
  const maxDistance = Math.sqrt(2) * (GAME_CONFIG.GRID_SIZE / 2);
  const priceMultiplier = 1 + (1 - centerDistance / maxDistance) * 2;
  return Math.round(GAME_CONFIG.PARCEL_BASE_PRICE * priceMultiplier);
}

// Generate parcel name
export function generateParcelName(x: number, y: number, region: string): string {
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const prefix = letters[Math.floor(x / 5)] + letters[Math.floor(y / 5)];
  return `${region.split(' ')[0]}-${prefix}${x}${y}`;
}
