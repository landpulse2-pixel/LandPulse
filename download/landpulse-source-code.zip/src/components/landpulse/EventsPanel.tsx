'use client';

import { useState, useEffect, useCallback } from 'react';
import { useGameStore } from '@/store/gameStore';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { GAME_CONFIG } from '@/lib/game-config';
import {
  Calendar,
  Trophy,
  Gift,
  Clock,
  Loader2,
  CheckCircle,
  Zap,
  Target,
  Brain
} from 'lucide-react';

interface Event {
  id: string;
  name: string;
  description: string;
  type: string;
  reward: number;
  startTime: string;
  endTime: string;
  active: boolean;
  hasParticipated: boolean;
}

export function EventsPanel() {
  const { walletAddress, setUser } = useGameStore();
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [playing, setPlaying] = useState(false);
  const [result, setResult] = useState<{ score: number; reward: number } | null>(null);

  const fetchEvents = useCallback(async () => {
    if (!walletAddress) return;

    setLoading(true);
    try {
      const response = await fetch(`/api/events?wallet=${walletAddress}`);
      const data = await response.json();
      setEvents(data.events || []);
    } catch (error) {
      console.error('Error fetching events:', error);
    } finally {
      setLoading(false);
    }
  }, [walletAddress]);

  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'quiz':
        return <Brain className="h-5 w-5" />;
      case 'prediction':
        return <Target className="h-5 w-5" />;
      case 'challenge':
        return <Zap className="h-5 w-5" />;
      default:
        return <Trophy className="h-5 w-5" />;
    }
  };

  const getEventColor = (type: string) => {
    switch (type) {
      case 'quiz':
        return 'text-blue-400';
      case 'prediction':
        return 'text-purple-400';
      case 'challenge':
        return 'text-orange-400';
      default:
        return 'text-yellow-400';
    }
  };

  const getTimeRemaining = (endTime: string) => {
    const end = new Date(endTime);
    const now = new Date();
    const remaining = end.getTime() - now.getTime();

    if (remaining <= 0) return 'Expiré';

    const hours = Math.floor(remaining / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days}j ${hours % 24}h`;
    return `${hours}h`;
  };

  const playEvent = async () => {
    if (!walletAddress || !selectedEvent) return;

    setPlaying(true);
    setResult(null);

    try {
      const response = await fetch('/api/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          walletAddress,
          eventId: selectedEvent.id,
        }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setResult({ score: data.score, reward: data.reward });
        setUser(data.user);
        fetchEvents();
      }
    } catch (error) {
      console.error('Error playing event:', error);
    } finally {
      setPlaying(false);
    }
  };

  const closeEvent = () => {
    setSelectedEvent(null);
    setResult(null);
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="grid gap-4">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold gradient-text flex items-center gap-2">
          <Calendar className="h-6 w-6" />
          Événements
        </h2>
        <p className="text-muted-foreground text-sm mt-1">
          Participez aux événements pour gagner des PulseBucks
        </p>
      </div>

      {/* Events Grid */}
      {events.length === 0 ? (
        <Card className="glass-card border-purple-500/20">
          <CardContent className="py-12 text-center text-muted-foreground">
            <Calendar className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>Aucun événement actif</p>
            <p className="text-sm mt-1">Revenez plus tard pour de nouveaux événements!</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {events.map((event) => (
            <Card
              key={event.id}
              className={`
                glass-card border-purple-500/20 cursor-pointer transition-all
                hover:border-purple-500/40 hover:shadow-lg hover:shadow-purple-500/10
                ${event.hasParticipated ? 'opacity-60' : ''}
              `}
              onClick={() => !event.hasParticipated && setSelectedEvent(event)}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-lg glass-card ${getEventColor(event.type)}`}>
                      {getEventIcon(event.type)}
                    </div>
                    <div>
                      <CardTitle className="text-lg">{event.name}</CardTitle>
                      <CardDescription className="text-sm mt-1">
                        {event.description}
                      </CardDescription>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 mb-2">
                      <Gift className="h-3 w-3 mr-1" />
                      {event.reward} PB
                    </Badge>
                    <div className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {getTimeRemaining(event.endTime)}
                    </div>
                  </div>
                </div>

                {event.hasParticipated && (
                  <div className="mt-3 flex items-center gap-2 text-green-400 text-sm">
                    <CheckCircle className="h-4 w-4" />
                    <span>Déjà participé</span>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Event Dialog */}
      <Dialog open={!!selectedEvent} onOpenChange={closeEvent}>
        <DialogContent className="glass-card border-purple-500/30 bg-[#0f0f1a]/95 max-w-md">
          <DialogHeader>
            {selectedEvent && (
              <div className="flex items-center gap-3">
                <div className={`p-3 rounded-lg gradient-bg text-white`}>
                  {getEventIcon(selectedEvent.type)}
                </div>
                <div>
                  <DialogTitle className="text-xl">{selectedEvent.name}</DialogTitle>
                  <DialogDescription>{selectedEvent.description}</DialogDescription>
                </div>
              </div>
            )}
          </DialogHeader>

          {!result ? (
            <div className="space-y-4 mt-4">
              <div className="glass-card rounded-lg p-4 text-center">
                <div className="text-sm text-muted-foreground mb-2">Récompense potentielle</div>
                <div className="text-3xl font-bold text-yellow-400">
                  {selectedEvent?.reward} PB
                </div>
              </div>

              <div className="text-sm text-muted-foreground text-center">
                Le score et la récompense seront calculés automatiquement
              </div>

              <Button
                onClick={playEvent}
                disabled={playing}
                className="w-full gradient-bg text-white"
              >
                {playing ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    En cours...
                  </>
                ) : (
                  <>
                    <Trophy className="h-4 w-4 mr-2" />
                    Participer
                  </>
                )}
              </Button>
            </div>
          ) : (
            <div className="space-y-4 mt-4">
              <div className="text-center py-6">
                <div className="text-6xl mb-4">🎉</div>
                <div className="text-2xl font-bold gradient-text mb-2">
                  Félicitations!
                </div>
                <div className="text-muted-foreground">
                  Score: <span className="text-white font-bold">{result.score}</span>
                </div>
              </div>

              <div className="glass-card rounded-lg p-4 text-center">
                <div className="text-sm text-muted-foreground mb-2">Vous avez gagné</div>
                <div className="text-3xl font-bold text-green-400">
                  +{result.reward} PB
                </div>
              </div>

              <Button
                onClick={closeEvent}
                className="w-full gradient-bg text-white"
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                Continuer
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
