'use client';

import { useGameStore } from '@/store/gameStore';
import { WalletConnect } from './WalletConnect';
import { DailyBonus } from './DailyBonus';
import { Button } from '@/components/ui/button';
import { 
  Map, 
  LayoutDashboard, 
  Calendar, 
  Coins,
  Sparkles
} from 'lucide-react';

export function Header() {
  const { user, isConnected, activeTab, setActiveTab } = useGameStore();

  return (
    <header className="sticky top-0 z-50 glass-card border-b border-purple-500/20">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-lg gradient-bg flex items-center justify-center">
                <Sparkles className="h-6 w-6 text-white" />
              </div>
              <div className="absolute -inset-1 gradient-bg opacity-30 blur-lg rounded-lg" />
            </div>
            <div>
              <h1 className="text-xl font-bold gradient-text">LandPulse</h1>
              <p className="text-xs text-muted-foreground hidden sm:block">
                Own virtual land. Earn passively. Build on Solana.
              </p>
            </div>
          </div>

          {/* Navigation */}
          {isConnected && (
            <nav className="hidden md:flex items-center gap-1">
              <Button
                variant={activeTab === 'map' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setActiveTab('map')}
                className={activeTab === 'map' ? 'gradient-bg text-white' : 'text-muted-foreground hover:text-white'}
              >
                <Map className="h-4 w-4 mr-2" />
                World Map
              </Button>
              <Button
                variant={activeTab === 'dashboard' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setActiveTab('dashboard')}
                className={activeTab === 'dashboard' ? 'gradient-bg text-white' : 'text-muted-foreground hover:text-white'}
              >
                <LayoutDashboard className="h-4 w-4 mr-2" />
                Dashboard
              </Button>
              <Button
                variant={activeTab === 'events' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setActiveTab('events')}
                className={activeTab === 'events' ? 'gradient-bg text-white' : 'text-muted-foreground hover:text-white'}
              >
                <Calendar className="h-4 w-4 mr-2" />
                Events
              </Button>
            </nav>
          )}

          {/* Right Section */}
          <div className="flex items-center gap-3">
            {isConnected && user && (
              <>
                {/* PulseBucks Display */}
                <div className="flex items-center gap-2 px-4 py-2 rounded-lg glass-card gradient-border border-0">
                  <Coins className="h-5 w-5 text-yellow-400" />
                  <span className="font-bold text-lg">{user.pulseBucks.toLocaleString()}</span>
                  <span className="text-xs text-muted-foreground">PB</span>
                </div>

                {/* Daily Bonus */}
                <DailyBonus />
              </>
            )}

            {/* Wallet Connect */}
            <WalletConnect />
          </div>
        </div>

        {/* Mobile Navigation */}
        {isConnected && (
          <nav className="flex md:hidden items-center justify-center gap-2 mt-3 pt-3 border-t border-purple-500/20">
            <Button
              variant={activeTab === 'map' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('map')}
              className={activeTab === 'map' ? 'gradient-bg text-white' : 'text-muted-foreground'}
            >
              <Map className="h-4 w-4" />
            </Button>
            <Button
              variant={activeTab === 'dashboard' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('dashboard')}
              className={activeTab === 'dashboard' ? 'gradient-bg text-white' : 'text-muted-foreground'}
            >
              <LayoutDashboard className="h-4 w-4" />
            </Button>
            <Button
              variant={activeTab === 'events' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('events')}
              className={activeTab === 'events' ? 'gradient-bg text-white' : 'text-muted-foreground'}
            >
              <Calendar className="h-4 w-4" />
            </Button>
          </nav>
        )}
      </div>
    </header>
  );
}
