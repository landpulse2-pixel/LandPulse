'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useGameStore } from '@/store/gameStore';
import { Gift, Clock, CheckCircle } from 'lucide-react';

export function DailyBonus() {
  const { user, setUser, walletAddress } = useGameStore();
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [claimed, setClaimed] = useState(false);

  const canClaim = () => {
    if (!user?.lastDailyBonus) return true;
    const lastBonus = new Date(user.lastDailyBonus);
    const now = new Date();
    const timeSince = now.getTime() - lastBonus.getTime();
    return timeSince >= 24 * 60 * 60 * 1000; // 24 hours
  };

  const getTimeRemaining = () => {
    if (!user?.lastDailyBonus) return null;
    const lastBonus = new Date(user.lastDailyBonus);
    const nextBonus = new Date(lastBonus.getTime() + 24 * 60 * 60 * 1000);
    const now = new Date();
    const remaining = nextBonus.getTime() - now.getTime();

    if (remaining <= 0) return null;

    const hours = Math.floor(remaining / (1000 * 60 * 60));
    const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));

    return `${hours}h ${minutes}m`;
  };

  const claimBonus = async () => {
    if (!walletAddress) return;

    setLoading(true);
    try {
      const response = await fetch('/api/user/daily-bonus', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ walletAddress }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setUser(data.user);
        setShowModal(true);
        setClaimed(true);
        setTimeout(() => {
          setShowModal(false);
          setClaimed(false);
        }, 3000);
      } else {
        console.error('Failed to claim bonus:', data.error);
      }
    } catch (error) {
      console.error('Error claiming bonus:', error);
    } finally {
      setLoading(false);
    }
  };

  const timeRemaining = getTimeRemaining();
  const canClaimNow = canClaim();

  return (
    <>
      <Button
        onClick={claimBonus}
        disabled={!canClaimNow || loading}
        variant={canClaimNow ? 'default' : 'outline'}
        size="sm"
        className={`relative overflow-hidden ${
          canClaimNow
            ? 'gradient-bg text-white pulse-glow'
            : 'glass-card border-purple-500/20 text-muted-foreground'
        }`}
      >
        {canClaimNow ? (
          <>
            <Gift className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">+10 PB</span>
            <span className="sm:hidden">+10</span>
          </>
        ) : (
          <>
            <Clock className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">{timeRemaining}</span>
            <span className="sm:hidden">{timeRemaining?.split(' ')[0]}</span>
          </>
        )}
      </Button>

      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="glass-card border-purple-500/30 bg-[#0f0f1a]/95 text-center">
          <DialogHeader>
            <div className="mx-auto mb-4 w-16 h-16 rounded-full gradient-bg flex items-center justify-center animate-pulse">
              <Gift className="h-8 w-8 text-white" />
            </div>
            <DialogTitle className="text-2xl gradient-text">
              Bonus Réclamé!
            </DialogTitle>
            <DialogDescription className="text-lg text-muted-foreground pt-2">
              Vous avez reçu <span className="text-yellow-400 font-bold">+10 PulseBucks</span>
            </DialogDescription>
          </DialogHeader>
          <div className="flex items-center justify-center gap-2 text-green-400 mt-4">
            <CheckCircle className="h-5 w-5" />
            <span>Revenez demain pour plus!</span>
          </div>
        </DialogContent>
      </Dialog>

      {/* Claimed Animation Overlay */}
      {claimed && (
        <div className="fixed inset-0 pointer-events-none z-50 flex items-center justify-center">
          <div className="text-6xl animate-bounce">
            🎁
          </div>
        </div>
      )}
    </>
  );
}
