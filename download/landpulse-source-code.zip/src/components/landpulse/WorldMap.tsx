'use client';

import { useState, useEffect, useCallback } from 'react';
import { useGameStore, Parcel } from '@/store/gameStore';
import { ParcelModal } from './ParcelModal';
import { Skeleton } from '@/components/ui/skeleton';
import { GAME_CONFIG } from '@/lib/game-config';
import { MapPin, ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function WorldMap() {
  const { walletAddress, parcels, setParcels, setSelectedParcel, isLoading, setLoading } = useGameStore();
  const [zoom, setZoom] = useState(1);
  const [hoveredParcel, setHoveredParcel] = useState<Parcel | null>(null);

  const fetchParcels = useCallback(async () => {
    if (!walletAddress) return;
    
    setLoading(true);
    try {
      const response = await fetch(`/api/parcels?wallet=${walletAddress}`);
      const data = await response.json();
      setParcels(data.parcels);
    } catch (error) {
      console.error('Error fetching parcels:', error);
    } finally {
      setLoading(false);
    }
  }, [walletAddress, setParcels, setLoading]);

  useEffect(() => {
    fetchParcels();
  }, [fetchParcels]);

  const handleParcelClick = (parcel: Parcel) => {
    setSelectedParcel(parcel);
  };

  const getParcelStyle = (parcel: Parcel) => {
    if (parcel.isOwnedByUser) {
      return 'parcel-owned';
    }
    if (parcel.isOwned) {
      return 'parcel-other';
    }
    return 'parcel-available';
  };

  const getRegionColor = (regionName: string) => {
    const region = GAME_CONFIG.REGIONS.find(r => r.name === regionName);
    return region?.color || '#8b5cf6';
  };

  if (isLoading) {
    return (
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-8 w-32" />
        </div>
        <Skeleton className="h-[600px] w-full rounded-lg" />
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      {/* Map Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold gradient-text flex items-center gap-2">
            <MapPin className="h-6 w-6" />
            World Map
          </h2>
          <p className="text-muted-foreground text-sm mt-1">
            Cliquez sur une parcelle pour l&apos;acheter ou voir les détails
          </p>
        </div>

        {/* Zoom Controls */}
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setZoom(Math.max(0.5, zoom - 0.25))}
            className="glass-card border-purple-500/20"
          >
            <ZoomOut className="h-4 w-4" />
          </Button>
          <span className="text-sm text-muted-foreground min-w-[3rem] text-center">
            {Math.round(zoom * 100)}%
          </span>
          <Button
            variant="outline"
            size="icon"
            onClick={() => setZoom(Math.min(2, zoom + 0.25))}
            className="glass-card border-purple-500/20"
          >
            <ZoomIn className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => setZoom(1)}
            className="glass-card border-purple-500/20"
          >
            <RotateCcw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap items-center gap-4 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded parcel-available" />
          <span className="text-muted-foreground">Disponible</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded parcel-owned" />
          <span className="text-muted-foreground">Votre parcelle</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded parcel-other" />
          <span className="text-muted-foreground">Autre propriétaire</span>
        </div>
        <div className="flex items-center gap-2 ml-auto">
          <span className="text-muted-foreground">Régions:</span>
          {GAME_CONFIG.REGIONS.map((region) => (
            <div key={region.name} className="flex items-center gap-1">
              <div
                className="w-3 h-3 rounded"
                style={{ backgroundColor: region.color, opacity: 0.6 }}
              />
              <span className="text-xs text-muted-foreground hidden sm:inline">
                {region.name.split(' ')[0]}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Map Grid */}
      <div className="relative overflow-auto rounded-lg glass-card p-4 scrollbar-thin">
        <div
          className="map-grid mx-auto"
          style={{
            gridTemplateColumns: `repeat(${GAME_CONFIG.GRID_SIZE}, minmax(0, 1fr))`,
            width: `${GAME_CONFIG.GRID_SIZE * (32 * zoom)}px`,
            maxWidth: '100%',
          }}
        >
          {parcels.map((parcel) => (
            <div
              key={`${parcel.x}-${parcel.y}`}
              onClick={() => handleParcelClick(parcel)}
              onMouseEnter={() => setHoveredParcel(parcel)}
              onMouseLeave={() => setHoveredParcel(null)}
              className={`
                relative aspect-square rounded cursor-pointer transition-all duration-200
                ${getParcelStyle(parcel)}
                parcel-hover
              `}
              style={{
                opacity: hoveredParcel?.id === parcel.id ? 1 : 0.8,
              }}
            >
              {/* Region color indicator */}
              <div
                className="absolute inset-0 rounded opacity-20"
                style={{
                  backgroundColor: getRegionColor(parcel.region),
                }}
              />

              {/* Parcel content */}
              <div className="absolute inset-0 flex items-center justify-center">
                {parcel.isOwnedByUser && (
                  <span className="text-xs">🏠</span>
                )}
                {parcel.isOwned && !parcel.isOwnedByUser && (
                  <span className="text-xs opacity-50">🔒</span>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Hovered Parcel Info */}
        {hoveredParcel && (
          <div className="absolute bottom-4 left-4 glass-card rounded-lg p-3 text-sm border border-purple-500/30">
            <div className="font-semibold text-white">{hoveredParcel.name}</div>
            <div className="text-muted-foreground text-xs">{hoveredParcel.region}</div>
            <div className="mt-1 text-yellow-400 font-mono">
              {hoveredParcel.price} PB
            </div>
            {hoveredParcel.isOwned && (
              <div className="text-xs text-green-400 mt-1">
                {hoveredParcel.isOwnedByUser ? 'Votre parcelle' : 'Possédée'}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="glass-card rounded-lg p-4 text-center">
          <div className="text-2xl font-bold gradient-text">
            {parcels.filter(p => p.isOwnedByUser).length}
          </div>
          <div className="text-xs text-muted-foreground">Vos parcelles</div>
        </div>
        <div className="glass-card rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-green-400">
            {parcels.filter(p => !p.isOwned).length}
          </div>
          <div className="text-xs text-muted-foreground">Disponibles</div>
        </div>
        <div className="glass-card rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-yellow-400">
            {parcels.filter(p => p.isOwnedByUser).reduce((sum, p) => sum + p.price, 0)}
          </div>
          <div className="text-xs text-muted-foreground">Valeur totale (PB)</div>
        </div>
        <div className="glass-card rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-purple-400">
            {parcels.filter(p => p.isOwnedByUser).reduce((sum, p) => sum + (p.buildings?.length || 0), 0)}
          </div>
          <div className="text-xs text-muted-foreground">Bâtiments</div>
        </div>
      </div>

      {/* Parcel Modal */}
      <ParcelModal onRefresh={fetchParcels} />
    </div>
  );
}
