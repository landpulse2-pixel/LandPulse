'use client';

import { useGameStore } from '@/store/gameStore';
import { Coins } from 'lucide-react';

export function PulseBucksDisplay() {
  const { user } = useGameStore();
  const pulseBucks = user?.pulseBucks ?? 0;

  return (
    <div className="flex items-center gap-2 px-4 py-2 rounded-xl glass-card">
      <div className="relative">
        <Coins className="w-5 h-5 text-yellow-400" />
        <div className="absolute inset-0 blur-sm">
          <Coins className="w-5 h-5 text-yellow-400" />
        </div>
      </div>
      <div className="flex flex-col">
        <span className="text-xs text-gray-400 uppercase tracking-wide">PulseBucks</span>
        <span className="text-lg font-bold gradient-text">{pulseBucks.toLocaleString()}</span>
      </div>
    </div>
  );
}
