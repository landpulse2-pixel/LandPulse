'use client';

import { useState, useEffect, useCallback } from 'react';
import { useGameStore, Building } from '@/store/gameStore';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { ScrollArea } from '@/components/ui/scroll-area';
import { GAME_CONFIG } from '@/lib/game-config';
import {
  LayoutDashboard,
  Coins,
  MapPin,
  Building2,
  TrendingUp,
  Clock,
  Loader2,
  Sparkles,
  ArrowUpRight,
  Wallet
} from 'lucide-react';

interface BuildingWithIncome extends Building {
  pendingIncome: number;
  hoursSinceCollection: number;
  parcel?: {
    name: string;
    x: number;
    y: number;
  };
}

export function Dashboard() {
  const { user, walletAddress, parcels, isLoading, setLoading } = useGameStore();
  const [buildings, setBuildings] = useState<BuildingWithIncome[]>([]);
  const [totalPendingIncome, setTotalPendingIncome] = useState(0);
  const [collecting, setCollecting] = useState(false);

  const fetchBuildings = useCallback(async () => {
    if (!walletAddress) return;

    setLoading(true);
    try {
      const response = await fetch(`/api/buildings?wallet=${walletAddress}`);
      const data = await response.json();
      setBuildings(data.buildings || []);
      setTotalPendingIncome(data.totalPendingIncome || 0);
    } catch (error) {
      console.error('Error fetching buildings:', error);
    } finally {
      setLoading(false);
    }
  }, [walletAddress, setLoading]);

  useEffect(() => {
    fetchBuildings();
    
    // Refresh buildings every minute to update pending income
    const interval = setInterval(fetchBuildings, 60000);
    return () => clearInterval(interval);
  }, [fetchBuildings]);

  const collectAllIncome = async () => {
    if (!walletAddress) return;

    setCollecting(true);
    try {
      const response = await fetch('/api/buildings/collect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ walletAddress }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        // Update user balance
        fetchBuildings();
      }
    } catch (error) {
      console.error('Error collecting income:', error);
    } finally {
      setCollecting(false);
    }
  };

  const ownedParcels = parcels.filter(p => p.isOwnedByUser);
  const totalBuildings = buildings.length;
  const totalIncomePerHour = buildings.reduce((sum, b) => sum + b.income, 0);

  // Calculate stats
  const stats = [
    {
      title: 'PulseBucks',
      value: user?.pulseBucks || 0,
      icon: Coins,
      color: 'text-yellow-400',
      suffix: 'PB',
    },
    {
      title: 'Parcelles',
      value: ownedParcels.length,
      icon: MapPin,
      color: 'text-purple-400',
      suffix: '',
    },
    {
      title: 'Bâtiments',
      value: totalBuildings,
      icon: Building2,
      color: 'text-cyan-400',
      suffix: '',
    },
    {
      title: 'Revenu/h',
      value: totalIncomePerHour,
      icon: TrendingUp,
      color: 'text-green-400',
      suffix: 'PB',
    },
  ];

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-lg" />
          ))}
        </div>
        <Skeleton className="h-48 rounded-lg" />
        <Skeleton className="h-64 rounded-lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold gradient-text flex items-center gap-2">
            <LayoutDashboard className="h-6 w-6" />
            Dashboard
          </h2>
          <p className="text-muted-foreground text-sm mt-1">
            Vue d&apos;ensemble de votre portfolio
          </p>
        </div>

        {/* Collect All Button */}
        {totalPendingIncome > 0 && (
          <Button
            onClick={collectAllIncome}
            disabled={collecting}
            className="gradient-bg text-white"
          >
            {collecting ? (
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
            ) : (
              <Sparkles className="h-4 w-4 mr-2" />
            )}
            Récolter {totalPendingIncome} PB
          </Button>
        )}
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <Card key={index} className="glass-card border-purple-500/20">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">{stat.title}</span>
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
              </div>
              <div className={`text-2xl font-bold ${stat.color}`}>
                {stat.value.toLocaleString()}
                {stat.suffix && <span className="text-sm ml-1">{stat.suffix}</span>}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Pending Income Card */}
      <Card className="glass-card border-purple-500/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg flex items-center gap-2">
            <Clock className="h-5 w-5 text-cyan-400" />
            Revenus en attente
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-3xl font-bold text-green-400">
                {totalPendingIncome} PB
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                De {buildings.length} bâtiment{buildings.length !== 1 ? 's' : ''}
              </p>
            </div>
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Potentiel journalier</div>
              <div className="text-xl font-bold text-purple-400">
                {totalIncomePerHour * 24} PB
              </div>
            </div>
          </div>

          {/* Income Progress */}
          {totalIncomePerHour > 0 && (
            <div className="mt-4">
              <div className="flex justify-between text-xs text-muted-foreground mb-1">
                <span>Progression horaire</span>
                <span>{Math.min(100, Math.round((totalPendingIncome / (totalIncomePerHour * 24)) * 100))}%</span>
              </div>
              <Progress 
                value={Math.min(100, (totalPendingIncome / (totalIncomePerHour * 24)) * 100)} 
                className="h-2 bg-purple-500/20"
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Buildings List */}
      <Card className="glass-card border-purple-500/20">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Building2 className="h-5 w-5 text-purple-400" />
            Vos Bâtiments
          </CardTitle>
        </CardHeader>
        <CardContent>
          {buildings.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Building2 className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p>Aucun bâtiment construit</p>
              <p className="text-sm mt-1">Achetez une parcelle et construisez des bâtiments pour générer des revenus!</p>
            </div>
          ) : (
            <ScrollArea className="h-[300px]">
              <div className="space-y-2 pr-4">
                {buildings.map((building) => {
                  const config = GAME_CONFIG.BUILDINGS[building.type as keyof typeof GAME_CONFIG.BUILDINGS];
                  
                  return (
                    <div
                      key={building.id}
                      className="flex items-center justify-between p-3 rounded-lg glass-card hover:border-purple-500/30 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{config?.emoji}</span>
                        <div>
                          <div className="font-medium">{building.name}</div>
                          <div className="text-xs text-muted-foreground">
                            {building.parcel?.name || `Parcelle (${building.parcelId.slice(0, 8)}...)`}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-green-400 font-mono">
                          +{building.pendingIncome} PB
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Niv. {building.level} • {building.income} PB/h
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>

      {/* Account Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="glass-card border-purple-500/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <ArrowUpRight className="h-4 w-4 text-green-400" />
              Total Gagné
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">
              {user?.totalEarned || 0} PB
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card border-purple-500/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Wallet className="h-4 w-4 text-red-400" />
              Total Dépensé
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-400">
              {user?.totalSpent || 0} PB
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
