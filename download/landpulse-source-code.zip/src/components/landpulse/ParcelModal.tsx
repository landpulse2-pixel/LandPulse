'use client';

import { useState } from 'react';
import { useGameStore, Parcel } from '@/store/gameStore';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { GAME_CONFIG } from '@/lib/game-config';
import { 
  MapPin, 
  Coins, 
  Building2, 
  ShoppingCart, 
  Loader2,
  CheckCircle,
  XCircle
} from 'lucide-react';

interface ParcelModalProps {
  onRefresh: () => void;
}

export function ParcelModal({ onRefresh }: ParcelModalProps) {
  const { selectedParcel, setSelectedParcel, user, walletAddress, setUser } = useGameStore();
  const [loading, setLoading] = useState(false);
  const [selectedBuilding, setSelectedBuilding] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!selectedParcel) return null;

  const handleClose = () => {
    setSelectedParcel(null);
    setSelectedBuilding(null);
    setSuccess(null);
    setError(null);
  };

  const buyParcel = async () => {
    if (!walletAddress || !selectedParcel) return;

    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/parcels/buy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          walletAddress,
          x: selectedParcel.x,
          y: selectedParcel.y,
        }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setUser(data.user);
        setSuccess(`Parcelle "${selectedParcel.name}" achetée avec succès!`);
        onRefresh();
      } else {
        setError(data.error || 'Erreur lors de l\'achat');
      }
    } catch (err) {
      setError('Erreur de connexion');
    } finally {
      setLoading(false);
    }
  };

  const buildOnParcel = async () => {
    if (!walletAddress || !selectedParcel || !selectedBuilding) return;

    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/buildings/build', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          walletAddress,
          parcelId: selectedParcel.id,
          buildingType: selectedBuilding,
        }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setUser(data.user);
        setSuccess(`${GAME_CONFIG.BUILDINGS[selectedBuilding as keyof typeof GAME_CONFIG.BUILDINGS].name} construit!`);
        onRefresh();
        setSelectedBuilding(null);
      } else {
        setError(data.error || 'Erreur lors de la construction');
      }
    } catch (err) {
      setError('Erreur de connexion');
    } finally {
      setLoading(false);
    }
  };

  const buildingTypes = Object.entries(GAME_CONFIG.BUILDINGS);
  const canAffordParcel = user && user.pulseBucks >= selectedParcel.price;

  return (
    <Dialog open={!!selectedParcel} onOpenChange={handleClose}>
      <DialogContent className="glass-card border-purple-500/30 bg-[#0f0f1a]/95 max-w-lg">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-lg gradient-bg flex items-center justify-center">
              <MapPin className="h-6 w-6 text-white" />
            </div>
            <div>
              <DialogTitle className="text-xl gradient-text">
                {selectedParcel.name}
              </DialogTitle>
              <DialogDescription className="text-muted-foreground">
                {selectedParcel.region} • Position ({selectedParcel.x}, {selectedParcel.y})
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        {/* Status Messages */}
        {success && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-green-500/10 border border-green-500/30 text-green-400">
            <CheckCircle className="h-5 w-5" />
            <span>{success}</span>
          </div>
        )}

        {error && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400">
            <XCircle className="h-5 w-5" />
            <span>{error}</span>
          </div>
        )}

        <Tabs defaultValue="info" className="mt-4">
          <TabsList className="grid w-full grid-cols-2 glass-card">
            <TabsTrigger value="info">Informations</TabsTrigger>
            {selectedParcel.isOwnedByUser && (
              <TabsTrigger value="build">Construire</TabsTrigger>
            )}
            {!selectedParcel.isOwned && (
              <TabsTrigger value="buy">Acheter</TabsTrigger>
            )}
          </TabsList>

          {/* Info Tab */}
          <TabsContent value="info" className="mt-4">
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="glass-card rounded-lg p-3">
                  <div className="text-sm text-muted-foreground">Prix</div>
                  <div className="text-xl font-bold text-yellow-400 flex items-center gap-2">
                    <Coins className="h-5 w-5" />
                    {selectedParcel.price} PB
                  </div>
                </div>
                <div className="glass-card rounded-lg p-3">
                  <div className="text-sm text-muted-foreground">Statut</div>
                  <div className="mt-1">
                    {selectedParcel.isOwnedByUser ? (
                      <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                        Votre parcelle
                      </Badge>
                    ) : selectedParcel.isOwned ? (
                      <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
                        Possédée
                      </Badge>
                    ) : (
                      <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">
                        Disponible
                      </Badge>
                    )}
                  </div>
                </div>
              </div>

              {selectedParcel.description && (
                <div className="glass-card rounded-lg p-3">
                  <div className="text-sm text-muted-foreground mb-1">Description</div>
                  <p className="text-sm">{selectedParcel.description}</p>
                </div>
              )}

              {selectedParcel.buildings && selectedParcel.buildings.length > 0 && (
                <div className="glass-card rounded-lg p-3">
                  <div className="text-sm text-muted-foreground mb-2">Bâtiments</div>
                  <div className="flex flex-wrap gap-2">
                    {selectedParcel.buildings.map((building) => (
                      <Badge key={building.id} variant="outline" className="border-purple-500/30">
                        {GAME_CONFIG.BUILDINGS[building.type as keyof typeof GAME_CONFIG.BUILDINGS]?.emoji} {building.name}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Buy Tab */}
          {!selectedParcel.isOwned && (
            <TabsContent value="buy" className="mt-4">
              <div className="space-y-4">
                <div className="glass-card rounded-lg p-4 text-center">
                  <div className="text-lg font-semibold mb-2">Acheter cette parcelle</div>
                  <div className="text-3xl font-bold text-yellow-400 mb-4">
                    {selectedParcel.price} PB
                  </div>
                  
                  {canAffordParcel ? (
                    <Button
                      onClick={buyParcel}
                      disabled={loading}
                      className="w-full gradient-bg text-white"
                    >
                      {loading ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : (
                        <ShoppingCart className="h-4 w-4 mr-2" />
                      )}
                      Acheter
                    </Button>
                  ) : (
                    <div className="text-red-400 text-sm">
                      PulseBucks insuffisants ({user?.pulseBucks || 0} / {selectedParcel.price})
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>
          )}

          {/* Build Tab */}
          {selectedParcel.isOwnedByUser && (
            <TabsContent value="build" className="mt-4">
              <div className="space-y-4">
                <div className="text-sm text-muted-foreground mb-2">
                  Sélectionnez un bâtiment à construire
                </div>
                
                <ScrollArea className="h-[200px] rounded-lg">
                  <div className="space-y-2 pr-4">
                    {buildingTypes.map(([type, config]) => {
                      const canAfford = user && user.pulseBucks >= config.price;
                      const isSelected = selectedBuilding === type;
                      
                      return (
                        <div
                          key={type}
                          onClick={() => canAfford && setSelectedBuilding(type)}
                          className={`
                            glass-card rounded-lg p-3 cursor-pointer transition-all
                            ${isSelected ? 'ring-2 ring-purple-500' : ''}
                            ${!canAfford ? 'opacity-50 cursor-not-allowed' : 'hover:border-purple-500/50'}
                          `}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <span className="text-2xl">{config.emoji}</span>
                              <div>
                                <div className="font-semibold">{config.name}</div>
                                <div className="text-xs text-muted-foreground">
                                  {config.description}
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-yellow-400 font-mono">{config.price} PB</div>
                              <div className="text-xs text-green-400">+{config.income} PB/h</div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </ScrollArea>

                {selectedBuilding && (
                  <Button
                    onClick={buildOnParcel}
                    disabled={loading}
                    className="w-full gradient-bg text-white"
                  >
                    {loading ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : (
                      <Building2 className="h-4 w-4 mr-2" />
                    )}
                    Construire {GAME_CONFIG.BUILDINGS[selectedBuilding as keyof typeof GAME_CONFIG.BUILDINGS].name}
                  </Button>
                )}
              </div>
            </TabsContent>
          )}
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
